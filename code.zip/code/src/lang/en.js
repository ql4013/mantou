// 英语
module.exports = {
    loginOrRegister: {
        // 登录
        login: 'Log In',
        // 注册
        register: 'Sign Up',
        // 用户名
        userName: 'Username',
        // 密码
        pwd: 'Password',
        // 重复密码
        repeatPwd: 'Repeat the password',
        // 邮箱
        email: 'Email',
        // 已有账号
        haveId: 'Already have an account?',
        // 立即登录
        nowLogin: 'Log In',
        // 登出
        logout: 'Sign Out'
    },
    nav: {
        //导航1（遨游世界）
        nav1: "World's Happening",
        // 导航2（留下脚印）
        nav2: 'Leave a Comment',
    },
    subTitle: {      
        // 评论
        comments: 'Comments',   
        // 搜索结果
        searchResult: 'Search results',
        // 详情
        description: 'Details'
    },
    other: {
        // 消息
        message: 'Message',
        // 请求超时，请重试！
        timeout: 'Request timed out, please try again!',
        // 修改成功
        modifySuccess: 'Successfully modified',
         // 提示
         tip: 'prompt',
        // 语言
        language: 'Language',
        // 提交评论中
        uploadCom: 'Submitting a comment, please wait...',
        // 取消
        cancel: 'Cancel',
        // 确定
        ok: 'Determine',
        // 回复
        reply: 'Reply',
        // 订阅
        subscribe: 'Subscription',
        // 喜欢
        likes: 'Like',
        // 分享
        share: 'Share',
        // 查看更多
        readMore: 'See more',
        // 查看更多回复
        moreReplies: 'See more replies',
        // 历史搜索
        historySearch: 'Historical search',
        // 热门搜索
        hotSearch: 'Popular searches',
        // 翻译自
        translatedFrom: 'Translated from ',
        // 翻译
        translate: 'Translate',
        // 加载中
        loading: 'Loading...',
        // 用户名和密码不能为空
        loginNull: 'Username and password cannot be empty',
        // 以上均为必填项
        allNull: 'All of the above are required',
        // 两次密码输入不一致，请修改
        verPwd: 'The password input is inconsistent twice, please modify',
        // 请登陆
        login: 'Please Sign in',
        // 暂无内容
        noContent: 'No content yet',
        // 无搜索结果
        noResult: 'No search results',
        // 暂无历史搜索记录
        noHistory: 'No historical search history',
        // 首次登陆欢迎语标题(欢迎来到Yooul！🌍)
        firstLoginTit: 'Welcome to Yooul! 🌍',
        // 首次登陆欢迎语（在这儿你可以与各个国家的人畅所欲言，所有留言都会被即时翻译）
        firstLogin: 'We detected your system language as English. ' +
                    'All posts and comments have been translated into English for you.',
        // 评论提示语(恭喜！您的评论已经被翻译成了6种语言。与世界各国的人互动吧！)
        firstComment: 'Congrats! Your comment has been translated into 6 languages. ',
        // 我的收藏
        myCollection: 'My Collection ',
        // 他的发表
        hisPublication: 'His Publication',
        // 查看全部
        seeAll: 'See All',
         // 公告
         notice: 'Welcome to Yooul! It is a place where you can communicate with people from all nations and exchange opinions on ' + 
                'various topics. Everything you post here will be instantly translated into 6 languages. '
    },
    lanObj: {
        'zh-CN': 'Simplified Chinese',
        ja: 'Japanese',
        ko: 'Korean',
        ar: 'Arabic',
        hi: 'Hindi',
        en: 'English',
        id: 'Indonesian'
    }

}