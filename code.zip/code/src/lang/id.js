// 印尼
module.exports = {
    loginOrRegister: {
        // 登录
        login: 'Login',
        // 注册
        register: 'Pendaftaran',
        // 用户名
        userName: 'Nama pengguna',
        // 密码
        pwd: 'Kata sandi',
        // 重复密码
        repeatPwd: 'Ulangi kata sandi',
        // 邮箱
        email: 'Kotak surat',
        // 已有账号
        haveId: 'Akun yang ada,',
        // 立即登录
        nowLogin: 'Masuk sekarang',
         // 登出
         logout: 'Keluar'
    },
    nav: {
        //导航1（遨游世界）
        nav1: 'Jelajahi dunia',
        // 导航2（留下脚印）
        nav2: 'Tinggalkan jejak kaki',
    },
    subTitle: {      
        // 评论
        comments: 'Komentar',
        // 搜索结果
        searchResult: 'Hasil pencarian',
        // 详情
        description: 'Detail'
    },
    other: {
         // 消息
         message: 'Pesan',
        // 请求超时，请重试！
        timeout: 'Permintaan habis, harap coba lagi!',
        // 修改成功
        modifySuccess: 'Berhasil dimodifikasi',
         // 提示
         tip: 'cepat',
        // 语言
        language: 'bahasa',
        // 提交评论中
        uploadCom: 'Kirim komentar, harap tunggu ...',
        // 取消
        cancel: 'Batalkan',
        // 确定
        ok: 'Tentukan',
        // 回复
        reply: 'Jawab',
        // 订阅
        subscribe: 'Berlangganan',
        // 喜欢
        likes: 'Seperti',
        // 分享
        share: 'Bagikan',
        // 查看更多
        readMore: 'Lihat lebih lanjut',
        // 查看更多回复
        moreReplies: 'Lihat lebih banyak balasan',
        // 历史搜索
        historySearch: 'Pencarian historis',
        // 热门搜索
        hotSearch: 'Pencarian populer',
        // 翻译自
        translatedFrom: 'Diterjemahkan dari ',
        // 翻译
        translate: 'Terjemahan',
        // 加载中..
        loading: 'Memuat...',
        // 用户名和密码不能为空
        loginNull: 'Nama pengguna dan kata sandi tidak boleh kosong',
        // 以上均为必填项
        allNull: 'Semua hal di atas diperlukan',
        // 两次密码输入不一致，请修改
        verPwd: 'Masukan kata sandi tidak konsisten dua kali, mohon modifikasi',
        // 请登陆
        login: 'Silakan masuk',
        // 暂无内容
        noContent: 'Tidak ada konten',
        // 无搜索结果
        noResult: 'Tidak ada hasil pencarian',
        // 暂无历史搜索记录
        noHistory: 'Tidak ada riwayat pencarian historis',
        // 首次登陆欢迎语标题(欢迎来到Yooul！🌍)
        firstLoginTit: 'Selamat datang di Yooul!🌍',
        // 首次登陆欢迎语（在这儿你可以与各个国家的人畅所欲言，所有留言都会被即时翻译）
        firstLogin: 'Kami mendeteksi bahasa sistem Anda sebagai bahasa Indonesia' + 
                    'Semua postingan dan komentar telah diterjemahkan ke dalam bahasa Indonesia untuk Anda.',
        // 评论提示语(恭喜！您的评论已经被翻译成了6种语言。与世界各国的人互动吧！)
        firstComment: 'Selamat, komen yang anda buat telah diterjemahkan ke 6 bahasa lainnya, silahkan menunggu balasan dari orang lain',
        // 我的收藏
        myCollection: 'Koleksi saya',
        // 他的发表
        hisPublication: 'Publikasi nya',
        // 查看全部
        seeAll: 'Lihat semua',
        // 公告
        notice: 'Hai, kita ada ngadain event giveaway nih dengan total hadiah sebesar 4 JUTA rupiah, buat yang mau ikutan caranya gampang, cek ' + 
                'website kami menurut kalian gimana, kemudian isi kuisionernya di sini: <a href="https://forms.gle/T7nypvBXzR4yZL4P9">https://forms.gle/T7nypvBXzR4yZL4P9 '
    },
    lanObj: {
        'zh-CN': 'Mandarin Sederhana',
        ja: 'Japanese',
        ko: 'Orang korea',
        ar: 'Arab',
        hi: 'Hindi',
        en: 'Bahasa inggris',
        id: 'Orang indonesia'
    }

}