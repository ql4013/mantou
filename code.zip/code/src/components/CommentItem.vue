<template>
    <div id="comment-item">
        <div class='user-info-box fr'>
            <div class="user-info">
                <span @click="userCenterHandle(subItem)">{{subItem.user_name + '  '}}</span>
                <span v-text="bannerList[subItem.comment_default_locale]"></span>
                <span class="fr">{{subItem.comment_created_at | timeFil}}</span>
            </div>
            <div class="info-box">
                <p v-if="subItem.showDefault" v-html="subItem.comment_content"></p>
                <p v-if="!subItem.showDefault" v-html="subItem.comment_default_content"></p>

                <div class="toole clearfix">
                    <span class="fl vm">
                        <i class="iconfont iconzan" :class="{'isLike': subItem.comment_like_state == 1}" @click="praiseHandle(subItem)"></i>
                        <span>{{subItem.comment_like_num}}</span>
                    </span>
                    <span class="fr vm" @click="commentHandle(subItem, index, subindex)">
                        <span>{{$t('other.reply')}}</span>
                        <i class="iconfont iconfenxiang"></i>
                    </span>
                </div>
                <div v-if="subItem.comment_default_locale && subItem.comment_default_locale != defaultLan">
                    <a v-if="subItem.showDefault" @click="translate(subItem)">{{$t('other.translatedFrom') + ' ' + languageList[defaultLan][subItem.comment_default_locale]}}</a>
                    <a v-else @click="translate(subItem)">{{$t('other.translate')}}</a>
                </div>
                
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'CommentItem',
        data () {

        }
    }
</script>

<style lang="scss" scoped>
    #comment-item {

    }
</style>    