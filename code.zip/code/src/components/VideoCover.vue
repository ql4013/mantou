<template>
    <div id="video-cover">
        <div class="pr box">
            <img :src="item.thumbnail">
            <div class="viewNum pa">
                <span>{{item.viewCounts}}</span>
                <span>Likes</span>
            </div>
            <i class="iconfont  pa"></i>
            <h3 class="pa">{{item.contentTitle}}</h3>
            <span class="pa classify">{{item.classify}}</span>
        </div>
    </div>
</template>
<script>
export default {
    name: 'VideoCover',
    data () {
        return {

        }
    },
    props: ['item']
}
</script>
<style lang="scss" scoped>
    #video-cover {
        .box {
            overflow: hidden;
            border-radius: .5rem;
            width: 100%;
            img {
                width: 100%;
            }
            .viewNum {
                top: .5rem;
                right: .5rem;
                border-radius: 1rem;
                padding: 0.2rem .5rem;
                color: #fff;
                font: {
                    size: .6rem;
                    weight: 600;
                };
                background: rgba(50, 50, 50, 0.6)

            }
            i {
                font: {
                    size: 3rem;
                };
                color: rgba(0, 0, 0, 0.9);
                left: calc(50% - 1.5rem);
                top: calc(50% - 1.5rem);
            }
            h3 {
                bottom: 2rem;
                left: 1rem;
                color: #fff;
                font: {
                    size: .8rem;
                    weight: 500;
                }
            }
            .classify {
                bottom: 1rem;
                left: 1rem;
                color: #fff;
                font: {
                    size: .6rem;
                    weight: 400;
                }
            }
        }
    }
</style>
