<template>
    <div id="media" >
        <h2>
            <!-- <span class="th" v-if="content">{{content.post_title}}</span> -->
        </h2>
        <div  class="media-box" v-if="content && content.post_content" v-html="content.post_content"></div>
        <!-- 预加载样式 -->
        <div v-if="isBefore" class="before-load"></div>
    </div>
</template>

<script>
    export default {
        name: 'MediaConent',
        props: ['content'],
        data () {
            return {
                isBefore : true
            }
        },
        watch: {
            content (nv, ov) {
                console.log(nv);
                this.isBefore = false;
                this.content = nv;
            }
        },
        methods: {
            
        },
        mounted () {
            
        }
    }
</script>

<style lang="scss" scoped>
    #media {
        background: #fff;
        border-bottom: 1px solid #ddd;
        h2 {
            background-color: #eee;
            border-bottom: 1px solid #ddd;
            height: 3.6rem;
            text-align: center;
            span {
                line-height: 3.6rem;
                width: 40%;
                display: inline-block;
            }
        }
        .media-box {
            padding: 1rem;
        }
        .before-load {
            width: calc(100% - 2rem);
            margin: 1rem;
            height: 12rem;
            background-color: #f4f4f4;
        }
    }

</style>