<template>
    <div class="content-item" @click="detialHandle(item)">
        <div class="item clearfix" v-if="item.post_type==='video' || item.post_type==='img'">
            <div class="item-left fl">
                <h3>{{item.post_title}}</h3>
                <p>{{item.post_created_at | timeFil}}</p>
                <div class="user">
                    <!-- <div class="user-img-box fl">
                        <img :src="item.user_avatar" alt="" srcset="">
                    </div> -->
                    <h4 class="fl">{{item.user_name}}</h4>
                </div>
            </div>
            <div class="item-right fr pr">
                <img @load="imgLoad(item)" v-if="item.post_media.video.video_thumbnail_url" :src="item.post_media.video.video_thumbnail_url" alt="" srcset="" >
                <i class="iconfont iconbofang pa" v-if="item.icon"></i>
            </div>
        </div>
        <div class="item-text" v-if="item.post_type === 'text'">
            <h3 class="th">{{item.post_title}}</h3>
            <p>{{item.post_content}}</p>
            <div class="user clearfix">
                <div class="user-img-box fl">
                    <img :src="item.user_avatar" alt="" srcset="">
                </div>
                <h4 class="fl">{{item.user_name}}</h4>
                <span class="fr">{{item.post_created_at | timeFil}}</span>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'ContentItem',
        props: ['item'],
        data () {
            return {

            }
        },
        methods: {
            detialHandle (item) {
                
                this.$router.push({
                    name: 'Detial',
                    query: {
                        uid: item.post_uuid
                    }
                });
            },
            imgLoad(item) {
                this.$set(item, 'icon', true)
            }
        },
        mounted () {
        }   
    }
</script>

<style lang="scss" scoped>
    .content-item {
        margin-bottom: 1rem;
        // max-height: 8rem;
        border-radius: 1rem;
        overflow: hidden;
        background: #fff;
        &:nth-last-child(1) {
            margin: 0;
        }
        .item {
            .item-left {
                width: 70%;
                padding: 1rem;
                h3 {
                    width: 100%;
                    // font-family: 'SemiBold_0';
                    font-size: 1rem;
                    overflow : hidden;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }
                p {
                    padding: .3rem 0;
                    color: #999;
                    font-size: .8rem;
                }
                .user {
                    .user-img-box {
                        width: 2rem;
                        height: 2rem;
                        overflow: hidden;
                        border-radius: 100%;
                        img {
                            // width: 100%;
                            height: 100%
                        }
                    }
                    h4 {
                        // font-family: 'Medium_0';
                        line-height: 2rem;
                        font-size: .8rem;
                    }
                }
            }
            .item-right {
                width: 30%;
                height: 8rem;
                img {
                    height: 100%;
                }
                i {
                    font-size: 2rem;
                    background: #fff;
                    height: 1.5rem;
                    width: 1.5rem;
                    line-height: 1.5rem;
                    border-radius: 100%;
                    top: calc(50% - 1rem);
                    left: calc(50% - 1rem);
                }
            }
        }
        .item-text {
            padding: 1rem;
            h3 {
                // font-family: 'SemiBold_0';
            }
            p {
                margin: .5rem 0;
                color: #222;
                width: 100%;
                max-height: 2.9rem;
                
                font: {
                    // family: 'Thin_0'
                }
                overflow : hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
            }
            .user {
                .user-img-box {
                    width: 2rem;
                    height: 2rem;
                    border-radius: 100%;
                    overflow: hidden;
                    img {
                        width: 100%;
                    }
                }
                h4 {
                    // font-family: 'Medium_0';
                    line-height: 2rem;
                    font-size: .8rem;
                    padding: 0 .5rem;
                }
                span {
                    padding: 0 .5rem;
                    color: #666;
                    line-height: 2rem;
                    font-size: .8rem;
                }
            }
        }
    }
</style>