<template>
    <div id="user-info">
        <div class="user-info-box clearfix">
            <div class="img-box fl">
                <img :src="userImg" alt="" srcset="">
            </div>
            <div class="user-info fl">
                <h3>{{userName}}</h3>
                <span>{{userTime}}</span>
            </div>
            <div class="user-tool-box fr">
                <i class="iconfont iconshoucang collect"></i>
                <i class="iconfont icontag"></i>
                <i class="iconfont icongengduo1"></i>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'userInfo',
    data () {
        return {
            userImg: require('../assets/img/titimg.png'),
            userName: 'Mike Jeans',
            userTime: '2hr ago'
        }
    }
}
</script>
<style lang="scss" scoped>
    #user-info {
        border-bottom: 1px solid rgb(245, 245, 245);
        .user-info-box {
            padding: 1rem;
            .user-info {
                padding: 0 1rem;
                span {
                    color: rgb(150, 150, 150);
                    font-size: 1rem;
                    
                }
            }
            .user-tool-box {
                i {
                    line-height: 3rem;
                    padding: 0 .5rem;
                    font: {
                        size: 1.6rem;
                    }
                }
            }
        }
    }
</style>
