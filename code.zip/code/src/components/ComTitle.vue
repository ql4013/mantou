<template>
    <div id="title">
        <div class="tit-con pr">
            <i v-if="isHome" class="iconfont iconApp_lingdang fl" @click="messageHandle()"></i>
            <div v-if="isHome" class="bg" @click="selectHandle()" data-value='en'>
                <span class="vm">{{selectLanguage | china  | toUpperCase}}</span><i class="vm"></i>
                
            </div>
            <input type="hidden" value id="">
            <span v-if="isHome && isNotRead != 1" class="pa">1</span>
            <i v-if="!isHome" class="iconfont icon_zhuye fl" @click="backHandle()"></i>
            <div class="tit-con-tool-box fr">          
                <form v-if="isSearch" class="vm" action="javascript:return true" v-on:keydown.enter="searchHandle()">
                    <input  type="search" v-model="searchCon">
                </form>
                
                <i class="iconfont iconchaxun vm" @click="searchHandle()"></i>
                <div class="img-box vm" @click='myCenterHandle()'>
                    <img :src=titUrl alt="" srcset="">
                </div>
            </div>
        </div>
        <div class="nav" v-if="isHome">
            <ul class="clearfix"> 
                <li class="fl th" :class="{ 'is-select' : index === isSelect}" v-for="(item, index) in navList" :key="index" @click="navSelectHandle(index)">{{item.title}}</li>
            </ul>
        </div>
    </div>
</template>
<script>
import IosSelect from 'iosselect'
import 'iosselect/src/iosSelect.css'
import gloabl_val from '../util/Gloabl'
export default {
    name: 'ComTitle',
    props: ['isHome'],
    data () {
        return {
            titUrl: localStorage.imgSrc  || 'https://qnidimage.mmantou.cn/userdefalutavatar.jpg',
            isSelect: 0,
            isMessage: false,
            isSearch: false,
            searchCon: '',
            isNotRead: localStorage.isNotRead,
            origin: window.location.origin,
            selectLanguage: 'en',
            data: [
                {'id': 'id', 'value': 'bahasa Indonesia'},
                {'id': 'ja', 'value': '日本語'},
                {'id': 'ar', 'value': 'العربية'},
                {'id': 'ko', 'value': '한국어'},
                {'id': 'hi', 'value': 'हिन्दी'},
                {'id': 'zh-CN', 'value': '简体中文'},
                {'id': 'en', 'value': 'English'},
            ],
            navList: [
                {
                    title: this.$t('nav.nav1'),
                    path: 'home'
                },
                {
                    title: this.$t('nav.nav2'),
                    path: 'entertain'
                }
            ]          
        }
    },
    filters: {
        toUpperCase(str) {
            return str.toUpperCase()
        },
        china (str) {
            return str.split('-')[0];
        }
    },

    methods: {
        navSelectHandle (index) {
            this.isSelect = index;
            if (this.navList[index].path === 'home') {
                this.$router.push('home');
            } else{
                this.$router.push(this.navList[index].path)
            }
            
        },
        toggleSearchHandle() {
            
            
        },
        selectHandle () {
            const bg = document.querySelector('.bg');
            var val = bg.dataset['id'];             // 获取元素的data-id属性值
            var title = bg.dataset['value'];        // 获取元素的data-value属性值
            // 实例化组件
            var example = new IosSelect(1,               // 第一个参数为级联层级，演示为1
                [this.data],                             // 演示数据
                {             // 容器class
                    title: this.$t('other.language'),                    // 标题
                    itemHeight: 50,                      // 每个元素的高度
                    itemShowCount: 3,                    // 每一列显示元素个数，超出将隐藏
                    oneLevelId: this.selectLanguage, 
                    sureText: this.$t('other.ok'),
                    closeText: this.$t('other.cancel'),
                                     // 第一级默认值
                    callback: selectOneObj => {  // 用户确认选择后的回调函数
                        this.selectLanguage = selectOneObj.id;
                        sessionStorage.language = selectOneObj.id;
                        // 语言切换
                        this.$i18n.locale = selectOneObj.id;
                        window.location.reload();
                    }
            });
        },
        myCenterHandle() { 
            if (localStorage.token) {
                this.$router.push({
                    name: 'Setting'
                })
            } else {
                this.$router.push({
                    name: 'Login'
                })
            }
            
        },
        messageHandle () {
            this.isMessage = true;
            this.$router.push('message');
        },
        backHandle () {
            window.location.href = this.origin + '/#/home'
        },
        searchHandle () {
            this.$router.replace({
                name: 'Search'
            });
            this.isSearch = true;
            if (this.searchCon) {
                this.$router.push({
                    name: 'SearchList',
                    query: {
                        keyword: this.searchCon
                    }
                })
                this.$root.Bus.$emit('searchResult')
            
               
                
            }
        },
        clearSearch() {
            this.isSearch = false;
            // this.searchCon = '';
        }
    },
    watch: {
        $route(to, form) {
            if (to.name == 'SearchList')  {
                this.searchCon = this.$route.query.keyword
            }
            
        }
    },
    mounted () {      
        let defaultLang = gloabl_val.default_language;      
        this.selectLanguage = sessionStorage.language || defaultLang;
        if (this.$route.name === 'Message') {
            this.isMessage = true;
        }
        if (this.$route.name === 'Search') {
            this.isSearch = true
        }
        const routeName = this.$route.path.slice(1);
        for (let i = 0; i < this.navList.length; i++) {
            if (this.navList[i].path === routeName) {
                this.isSelect = i;
            }
            
        }
        this.$root.Bus.$on('searchSource', this.searchHandle);
        this.$root.Bus.$on('clearSearch', this.clearSearch);
        this.$root.Bus.$on('updateUserImg', imgSrc => {
            this.titUrl = imgSrc
        });
        this.$root.Bus.$on('clearUserInfo', () => {
            this.titUrl = localStorage.imgSrc;
        })
        this.$root.Bus.$on('cancelTip', () => {
            this.isNotRead = 1;
        } );
    },
    beforeDestroy () {
        this.$root.Bus.$off('searchSource');
        this.$root.Bus.$off('clearSearch');
        this.$root.Bus.$off('updateUserImg');
        this.$root.Bus.$off('clearUserInfo');
        this.$root.Bus.$off('cancelTip');
    }

}
</script>
<style lang="scss" scoped>
    $fontSize: 1.2rem;
    $fontWeight: 700;
    #title {
        background: rgb(20, 18, 18);
        padding-top: .5rem;
        .tit-con {
            .bg {
                position: absolute;
                left: 2.8rem;
                top: 0.75rem;
                height: 1.5rem;
                padding-left: .3rem;
                width: 3.6rem;
                line-height: 1.4rem;
                border-radius: 2rem;
                height: 1.5rem;
                // font-family: 'SemiBold_0';
                color: #fff;
                font-weight: bolder;
                background: rgb(211, 127, 0);
                
                i {
                    width: 1.4rem;
                    height: 1.4rem;
                    // border: 1px solid #fff;
                    display: inline-block;
                    background: url('../assets/img/Down.png') no-repeat  50% 50%;
                    transform: scale(.5);
                }
            }
            padding-bottom: 1rem;
            height: 3rem;
            text-align: center;
            line-height: 3rem;
            margin: 0 5.5%;
            i {
                color: #fff;
                font-size: 1.3rem;
                font-weight: 100;
            }
            .iconApp_lingdang {
                font-size: 1.3rem;
                font-weight: 700;
            }
            .icondown {
                color: #fff;
            }
            span {
                color: #fff;
                width: 1rem;
                height: 1rem;
                font-size: .8rem;
                font-size: .7rem;
                border-radius: 100%;
                background-color: rgb(211, 127, 0);
                left: .9rem;
                top: .5rem;
                line-height: 1rem;
            }
            .tit-con-tool-box {
                form {
                    display: inline-block;
                    height: 2rem;
                    line-height: 2rem;
                    border-radius: .5rem;
                    padding: 0 1rem;
                    outline: none;
                    background: #fff;
                    
                    font: {
                        size: 1rem;
                        
                    }
                    input {
                        outline: none
                    }
                }
                .img-box {
                    width: 2.1rem;
                    height: 2.1rem;
                    img {
                        width: 100%;
                        height: 100%;
                    }
                }
                i {
                    color: #fff;
                    margin:  0 .6rem;
                    font-size: 1.3rem;
                    font-weight: 100;
                }
            }
        }
        .nav {
            color: #fff;
            width: 100%;
            bottom: 0;
            // padding-top: 1rem;
            ul {
                li {
                    width: 50%;
                    text-align: center;
                    padding: 1rem 1%;
                    // font-family: 'SemiBold_0';
                }
                .is-select {
                    border-bottom: 5px solid rgb(211, 127, 0) 
                }
            }
        }
    }
</style>
