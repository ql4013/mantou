<template>
    <div id="comment-box">
        <div class="comment-con">
            <!-- <h3>{{$t('subTitle.topComments')}}</h3> -->
            <ul class="comment-item" v-if="comList">
                <li v-for="(item, index) in comList" :key="index"> 
                    <div class="com-item clearfix">
                        <!-- <div class="img-box fl">
                            <img :src="item.user_avatar" alt="">
                        </div> -->
                        <div class="com-user-info fl">
                            <h4>
                                <span class="vm">{{item.user_name}}</span>    
                                <span v-text="bannerList[item.comment_default_locale]"></span>
                            </h4> 
                            <p v-html="item.comment_content"></p>
                        </div>
                        <div class="com-user-time fr">
                            <span>{{item.comment_created_at  | timeFil}}</span>
                            <span>{{item.comment_like_num + ' ' + $t('other.likes')}}</span>
                        </div>
                    </div>
                </li>
                <li class="clearfix lastItem">
                    <div class="fl">
                        <!-- <div class="img-box fl"  v-for="(item, index) in comList" :key="index">
                            <img :src="item.user_avatar || defaultImg" alt="" srcset="">
                        </div> -->
                        <!-- {{comList[0]}} -->
                        <div class="img-box fl">
                            <img v-if="comList[0]" :src="comList[0].user_avatar" alt="">
                            <img v-else :src="defaultImg" alt="" srcset="">
                        </div>
                        <span  class="fl">{{comNum + " " + $t('other.reply')}}</span>
                    </div>
                    <div class="fr">
                        <span class="vm">{{$t('other.seeAll')}}</span>
                        <i class="iconfont icongengduocopy vm"></i>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {
    name: 'Comment',
    props: ['comList', 'comNum'],
    data () {
        return {
           defaultImg: localStorage.imgSrc,
            bannerList: {
                en: '🇺🇸',
                ja: '🇯🇵',
                ar: '🇦🇼',
                ko: '🇰🇷',
                hi: '🇮🇳',
                'zh-CN': '🇨🇳',
                id: '🇮🇩'
            }
        }
    },
    mounted() {
    },
}
</script>
<style lang="scss" scoped>
    #comment-box {
        .comment-con {
            h3 {
                padding: 1rem;
            }
            .comment-item {
                padding: 0 1rem;
                li {
                    padding: .5rem 0;
                    border-bottom: 1px solid rgb(225, 225, 225);
                    
                }
                .lastItem {
                    line-height: 1.6rem;
                    border: none;
                    padding-left: 1rem;
                    div {
                        .img-box {
                            width: 1.6rem;
                            height: 1.6rem;
                        }
                        .img-box:not(:nth-of-type(1)) {
                            margin-left:  -0.4rem; 
                        }
                        span {
                            padding: 0 .5rem;
                        }
                    }
                    .fl {
                        color: #a6a6a6;
                        font-size: .8rem;
                        span {
                            margin-left: .5rem;
                        }
                    }
                    .fr {
                        color: #e99400;
                        font-size: .9rem;
                    }
                    
                }
                .com-user-info {
                    width: 70%;
                    padding: 0 1rem;
                    span {
                        // font-family: 'SemiBold_0';
                        color: #151515
                    }
                    i {

                    }
                    p {
                        display: -webkit-box;
                        max-height: 2.6rem;
                        padding-top: .2rem;
                        line-height: 1.2rem;
                        // font-family: 'Light';
                        text-overflow: ellipsis;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 3;
                        overflow: hidden;
                        font: {
                            size: .8rem;
                            weight: 400;
                        }
                    }
                }
                .com-user-time {
                    span {
                        display: block;
                        padding-top: .3rem;
                        color: #7a7a7a;
                        font: {
                            size: .8rem;
                            family: 'Regular';
                            weight: bold
                        }
                        &:nth-of-type(2) {
                            color: #a6a6a6;
                            padding-top: .2rem;
                        }
                    }
                }
            }
        }
    }
</style>
