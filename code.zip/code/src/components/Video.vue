<template>
    <div id="video-box">
        <!-- <h3 v-if="!isDetial">{{conTitle}}</h3> -->
        <div class="video-con">
            <video ref='videoPlayer' class="video-js" webkit-playsinline='true' playsinline='true'></video>
        </div>
    </div>
</template>
<script>
import video from 'video.js'
export default {
    name: 'VideoPlayer',

    props: ['content'],
    data () {
        return {
            player: null,
            options: {
                width: 0,
                controls: true,
                sources: [
					{
						src: (this.content.post_media.video.video_url),
						type: "video/mp4"
					}
				] 
            },
        }
    },
    methods: {
        onPlayerReady(player) {
        }
    },
    mounted() {
        this.options.width = document.querySelector('#video-box').offsetWidth;
        this.player = video(this.$refs.videoPlayer, this.options, this.onPlayerReady(this));
    },
    beforeDestroy() {
        if (this.player) {
            this.player.dispose()
        }
    }
}
</script>
<style lang="scss" scoped>
    #video-box {
        h3 {
            padding: 1rem;
            font: {
                size: 1rem;
                weight: 400;
            }
        }
    }
</style>

