<template>
    <div id="comment">
        <div class="comment-input">
            <div class="input-box">
                <input type="text"  v-model="commentCon" :placeholder="placeholder" @focus="focusHandle()" @blur="blurHandle()">
                <button class="fr" @click="publishCommentHandle()" :disabled='commentDisable'>
                    <i class="iconfont iconsend"></i>
                </button>
            </div>
            
        </div>
        <div class="comment-list">
            <ul v-if="commentInfoList.length && isLoaded">
                <li v-for="(item,index) in commentInfoList" :key="index">
                    <div class="comment-con clearfix">
                        <!-- <div class="user-img-box fl"  @click="userCenterHandle(item)">
                            <img :src="item.user_avatar || defultImg" alt="">
                        </div> -->
                        <div class='user-info-box fr'>
                             <div class="user-info">
                                <span @click="userCenterHandle(item)">{{item.user_name + '  '}} </span>
                                <span>{{bannerList[item.comment_default_locale]}}</span>
                                <span class="fr">{{item.comment_created_at | timeFil}}</span>
                            </div>
                            <div class="info-box">
                                <p v-if="item.showDefault" v-html="item.comment_content"></p>
                                <p v-if="!item.showDefault" v-html="item.comment_default_content"></p>
                                <div class="toole clearfix">
                                    <span class="fl vm">
                                        <i v-if="!zanDisable" class="iconfont iconzan" :class="{'isLike': item.comment_like_state == 1}" @click="praiseHandle(item)"></i>
                                        <i v-if='zanDisable' class="iconfont iconzan" :class="{'isLike': item.comment_like_state == 1}"></i>
                                        <span>{{item.comment_like_num}}</span>
                                    </span>
                                    <span class="fr vm" @click="commentHandle(item, index)">
                                        <span>{{$t('other.reply')}}</span>
                                        <i class="iconfont iconfenxiang"></i>
                                    </span>
                                </div>
                                <div v-if="item.comment_default_locale && item.comment_default_locale != defaultLan">
                                    <a v-if="item.showDefault" @click="translate(item)">{{$t('other.translatedFrom') + ' ' + languageList[defaultLan][item.comment_default_locale]}}</a>
                                    <a v-else @click="translate(item)">{{$t('other.translate')}}</a>
                                </div>
                            </div>
                            <!-- <p @click="moreReplyHandle(item)">--More replies--</p> -->
                        </div>
                       
                    </div>
                    <div class="reply-list">
                        <ol v-if="item.children">
                            <li class="clearfix" v-for="(subItem, subindex) in item.children" :key="subindex">
                                <!-- <div class="user-img-box fl"  @click="userCenterHandle(subItem)">
                                    <img :src="subItem.user_avatar" alt="">
                                </div> -->
                                <div class='user-info-box fr'>
                                    <div class="user-info">
                                        <span @click="userCenterHandle(subItem)">{{subItem.user_name + '  '}}</span>
                                        <span v-text="bannerList[subItem.comment_default_locale]"></span>
                                        <span class="fr">{{subItem.comment_created_at | timeFil}}</span>
                                    </div>
                                    <div class="info-box">
                                        <p v-if="subItem.showDefault" v-html="subItem.comment_content"></p>
                                        <p v-if="!subItem.showDefault" v-html="subItem.comment_default_content"></p>

                                        <div class="toole clearfix">
                                            <span class="fl vm">
                                                <i class="iconfont iconzan" :class="{'isLike': subItem.comment_like_state == 1}" @click="praiseHandle(subItem)"></i>
                                                <span>{{subItem.comment_like_num}}</span>
                                            </span>
                                            <span class="fr vm" @click="commentHandle(subItem, index, subindex)">
                                                <span>{{$t('other.reply')}}</span>
                                                <i class="iconfont iconfenxiang"></i>
                                            </span>
                                        </div>
                                        <div v-if="subItem.comment_default_locale && subItem.comment_default_locale != defaultLan">
                                            <a v-if="subItem.showDefault" @click="translate(subItem)">{{$t('other.translatedFrom') + ' ' + languageList[defaultLan][subItem.comment_default_locale]}}</a>
                                            <a v-else @click="translate(subItem)">{{$t('other.translate')}}</a>
                                        </div>
                                        
                                    </div>
                                </div>
                            </li>
                        </ol>
                    </div>
                    
                </li>
                
            </ul>
            <!-- 预加载样式 -->
            <ul v-if="!isLoaded" class="beforeLoad">
                <li v-for="i in 3">
                    <div class="name"></div>
                    <div class="con clearfix">
                        <div class="com"></div>
                        <p></p>
                        <div class="sub fr">
                            <div class="name"></div>
                            <div class="con">
                                <div class="com"></div>
                                <p></p>
                            </div>    
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <p v-if="lookMore" @click="moreCommentHandle()">
            <i class="iconfont icongengduo"></i>
        </p>
    </div>
</template>
<script>
import videoCover from '../components/VideoCover'
import { Indicator } from 'mint-ui'
import { Toast } from 'mint-ui'
import { MessageBox } from 'mint-ui';
import {getCommentList} from '../service/api'
import gloabl_val from '../util/Gloabl';

export default {
    name: 'ComDetial',
    data () {
        return {
            keyOpenH: 0,
            keyCloseH: 0,
            defultImg: require('../assets/img/titimg.png'),
            commentInfoList: [],
            currentPage: null,
            childCurrentPage: null,
            defaultLan: "",
            publishTo: '',
            loading: false,
            isLoaded: false,
            lookMore: true,
            commentDisable: false,
            replyIndex: -1,
            subReplyIndex: -1,
            zanDisable: false,
            commentCon: '',
            placeholder: this.$t('subTitle.comments'),
            languageList: {
                en: {
                    'zh-CN': 'Simplified Chinese',
                    ja: 'Japanese',
                    ko: 'Korean',
                    ar: 'Arabic',
                    hi: 'Hindi',
                    en: 'English',
                    id: 'Indonesian'
                },
                ko: {
                    'zh-CN': '중국어 간체',
                    ja: '일본어',
                    ko: '한국어',
                    ar: '아랍어',
                    hi: '힌디어',
                    en: '영어',
                    id: '인도네시아어'
                },
                ja: {
                    'zh-CN': '簡体字中国語',
                    ja: '日本語',
                    ko: '韓国人',
                    ar: 'アラビア語',
                    hi: 'ヒンディー語',
                    en: '英語',
                    id: 'インドネシア人'
                },
                hi: {
                    'zh-CN': 'सरलीकृत चीनी',
                    ja: 'जापानी',
                    ko: 'कोरियाई',
                    ar: 'अरबी भाषा',
                    hi: 'हिन्दी',
                    en: 'अंग्रेजी',
                    id: 'इन्डोनेशियाई'
                },
                id: {
                    'zh-CN': 'Mandarin Sederhana',
                    ja: 'Japanese',
                    ko: 'Orang korea',
                    ar: 'Arab',
                    hi: 'Hindi',
                    en: 'Bahasa inggris',
                    id: 'Orang indonesia'
                },
                'zh-CN': {
                    'zh-CN': '简体中文',
                    ja: '日语',
                    ko: '韩语',
                    ar: '阿拉伯语',
                    hi: '印地语',
                    en: '英语',
                    id: '印尼语'
                },
                ar: {
                    'zh-CN': 'الصينية المبسطة',
                    ja: 'اليابانية',
                    ko: 'الكورية',
                    ar: 'العربية',
                    hi: 'الهندية',
                    en: 'الإنجليزية',
                    id: 'الأندونيسية'
                }
            },
            bannerList: {
                en: '🇺🇸',
                ja: '🇯🇵',
                ar: '🇦🇼',
                ko: '🇰🇷',
                hi: '🇮🇳',
                'zh-CN': '🇨🇳',
                id: '🇮🇩'
            }
        }
    },
    
    methods: {
        // 翻译
        translate (item, e) {   
            item.showDefault = !item.showDefault
        },
        focusHandle() {
            const input = document.querySelector('.comment-input input');
            const fs = parseFloat(getComputedStyle(document.querySelector('html'),undefined).fontSize);
            this.keyOpenH = document.body.clientHeight || document.documentElement.clientHeight;
            input.style.bottom= this.keyCloseH - this.keyOpenH + fs * 3 + 'px';
        },
        blurHandle () {
            const input = document.querySelector('.comment-input');
            input.style.bottom = 0;
        },
        userCenterHandle(item) {
            this.$router.push({
                path: '/setting',
                query: {
                    uid: item.user_id
                }
            })
        },
        // 回复评论
        commentHandle(item, index, subindex) { 
            index && (this.replyIndex  = index);
            subindex && (this.subReplyIndex = subindex);
            document.querySelector('.comment-input input').focus();
            this.publishTo = item.comment_comment_p_id;
            this.commentCon = '';
            this.placeholder = 'reply to ' + item.user_name;
        },
        // 初始化加载评论
        loadComment (uid) {
            Indicator.open(this.$t('other.loading'))
            const p = {
                uid: uid,
            }
            // this.$axios.defaults.headers.common['Authorization'] = localStorage.token; 
            getCommentList(p).then( res => {
            // this.$axios.get('postComment/post/' + uid + '?children=true').then( res => {
                
                Indicator.close();
                this.currentPage = res.data;
                
                this.commentInfoList = res.data.data;
                // 是否存在下一页
                if (!res.data.links.next) {
                    this.lookMore = false; 
                }
                // 加载完毕隐藏预加载Dom
                this.isLoaded = true;
                if (this.commentInfoList.length) {
                    for (let i = 0; i < this.commentInfoList.length; i++) {                                 
                        this.$set(this.commentInfoList[i], 'showDefault', true)
                        const children =  this.commentInfoList[i].children;
                        if ( children && children.length) {
                            for (let j = 0; j < children.length; j++) {
                                this.$set(children[j], 'showDefault', true)
                            }
                        }           
                    }
                }
                
                
                Indicator.close();
            })
        },
        // 展开更多回复
        moreReplyHandle (item) {
            for (let i = 0; i < item.children.length; i++) {
                if(i !== 0 && item.viewList.length !== item.children.length) {
                    item.viewList.unshift(item.children[i]);

                }
                
            }
            
        },
        // 展开更多评论
        moreCommentHandle () {
            const dataList = this.currentPage;
            const uid = this.$route.query.uid;
            if ( dataList && dataList.links.next ) {
                
                Indicator.open(this.$t('other.loading'));
                const next = dataList.links.next;
                const urlParams = new URLSearchParams(next);
                const pageNum = urlParams.get('comment_page');
                this.$axios.get('postComment/post/' + uid + "?children=true&comment_page=" + pageNum).then( res => {
                   
                    for (let i = 0; i < res.data.data.length; i++) {
                        this.$set(res.data.data[i], 'showDefault', true)
                        
                    }
                    this.commentInfoList.push(...res.data.data)
                    this.currentPage = res.data
                     Indicator.close();
                })
            } else {
                this.lookMore = false;
                // Toast(this.$t('other.end'));
            }
            
        },
        // 点赞
        praiseHandle(item) {
            console.log(item)
            this.$axios.defaults.headers.common['Authorization'] = localStorage.token; 
            
            if (item.comment_like_state == 1 && !this.zanDisable) {
                this.zanDisable = true
                this.$axios.put('postComment/' + item.comment_id + '/revokeVote').then( res => {
                    // if (res.status === 204) {
                        this.zanDisable = false;
                        item.comment_like_state = -1;
                        item.comment_like_num -= 1
                        localStorage.token = res.config.headers.Authorization;
                    // }
                }).catch( err => {
                    if (err.message.indexOf('timeout') != -1) {
                        Toast(this.$t('other.timeout'))
                        return;
                    }
                    
                    const errCode = (err.response && err.response.status);
                        this.zanDisable = false;
                        // Toast(this.$t('other.loginLoseEfficacy'));
                        MessageBox({
                            confirmButtonText: '123',
                            cancelButtonText: '123'
                        }).confirm(
                            this.$t('other.login'),
                            'Prompt',
                            
                        ).then(action => {
                            this.$router.push({
                                name: 'Login'
                            })
                            
                        });
                        
                    
                })
            } else if (item.comment_like_state != 1 && !this.zanDisable){
                this.zanDisable = true
                this.$axios.put('postComment/' + item.comment_id + '/like').then( res => {
                    // if (res.status === 204) {
                        item.comment_like_state = 1;
                        item.comment_like_num += 1;
                        this.zanDisable = false;                      
                        window.localStorage.token = res.config.headers.Authorization;
                    // }
                    
                }).catch( err => {
                    if (err.message.indexOf('timeout') != -1) {
                        Toast(this.$t('other.timeout'))
                        return;
                    }
                    this.zanDisable = false; 
                    const errCode = (err.response && err.response.status);
                    if (errCode && (errCode == 401 || errCode == 500)) {
                        MessageBox({
                            title: this.$t('other.tip'),
                            message: this.$t('other.login'),
                            showCancelButton: true,
                            confirmButtonText: this.$t('other.ok'),
                            cancelButtonText: this.$t('other.cancel')
                        }).then(action => {
                            if (action == 'confirm') {
                                this.$router.push({
                                    name: 'Login'
                                })
                            } else {
                                return;
                            }
                            
                        });
                    } else {
                        
                        Toast(err.response.data.message)
                    }
                        
                        
                })
            }
        },
        // 发表评论
        publishCommentHandle() {
            const content = this.trim(this.commentCon);
            const uuid = this.$route.query.uid;     
            this.$axios.defaults.headers.common['Authorization'] = localStorage.token;
            if (content) {
                if (localStorage.token) {
                    
                
                    Indicator.open(this.$t('other.uploadCom'))
                    this.commentDisable= true;
                    this.$axios.post('postComment', {
                        post_uuid: uuid,
                        comment_content: content,
                        comment_comment_p_id: this.publishTo || 0
                    }).then( res => {
                        this.$root.Bus.$emit('showPop', this.$t('other.firstComment'));                   
                        this.commentDisable= false;
                        let time = new Date();
                        Indicator.close()
                        time = time.getFullYear() + '-' + (time.getMonth() + 1) + '-' + time.getDate() + ' ' + time.getHours() + ':' + time.getMinutes() + ':' + time.getSeconds()
                        
                        const newCom = {
                            user_avatar: localStorage.imgSrc,
                            user_name: localStorage.userName,
                            comment_created_at: time,
                            comment_content: content,
                            comment_like_state: 0,
                            comment_like_num: 0,
                            showDefault: true

                        }
                        window.localStorage.token = res.config.headers.Authorization;
                        
                        if (this.replyIndex === -1 && this.subReplyIndex === -1) {
                            this.commentInfoList.unshift(newCom);
                        } else if(this.replyIndex !== -1 && this.subReplyIndex === -1) {
                            this.commentInfoList[this.replyIndex].children.unshift(newCom);
                        } else {
                            this.commentInfoList[this.replyIndex].children.splice((this.subReplyIndex + 1), 0, newCom)
                        }
                        
                        this.commentCon = '';
                    }).catch( err => {
                        this.commentDisable= false;
                        Indicator.close()
                        if (err.message.indexOf('timeout') != -1) {
                            Toast(this.$t('other.timeout'))
                            return;
                        }
                        const errCode = (err.response && err.response.status); 
                        if (errCode && (errCode == 401 || errCode == 500)) {
                            MessageBox({
                                title: this.$t('other.tip'),
                                message: this.$t('other.login'),
                                showCancelButton: true,
                                confirmButtonText: this.$t('other.ok'),
                                cancelButtonText: this.$t('other.cancel')
                            }).then(action => {
                                if (action == 'confirm') {
                                    this.$router.push({
                                        name: 'Login'
                                    })
                                } else {
                                    return;
                                }
                                
                            });
                        } else {
                            
                            Toast(err.response.data.message)
                        }
                        
                    })
                } else {
                    
                    
                     MessageBox({
                        title: this.$t('other.tip'),
                        message: this.$t('other.login'),
                        showCancelButton: true,
                        confirmButtonText: this.$t('other.ok'),
                        cancelButtonText: this.$t('other.cancel')
                    }).then(action => {
                        if (action == 'confirm') {
                            this.$router.push({
                                name: 'Login'
                            })
                        } else {
                            return;
                        }
                        
                    });
                }
            }
            
        },
        // 去除前后空格
        trim (str) {
            return str.replace(/(^\s*)|\s*$/g,'')
        },
        // 动态计算评论区高度
        countH() {
            const nav = document.querySelector('.detial-module-info');
            const navH = nav.offsetTop;
            const ul = nav.querySelector('ul');
            // const con = document.querySelector('.comment-list');
                // 可视高度
            const seeH = document.documentElement.clientHeight;
            const sH = document.documentElement.scrollTop || document.body.scrollTop;
            if (sH > navH) {
                ul.style.position='fixed';
                ul.style.top='0';
                ul.style.width= '100%';
                ul.style.background= '#fff';
            } else {
                ul.style.position='static';
            }
            
        },
    },

    mounted () {
        const app = document.querySelector('body')
        app.addEventListener('scroll', () => {
           this.countH() 
            
        
        });
        this.defaultLan = sessionStorage.language ||  gloabl_val.default_language;
        const devH = document.body.scrollHeight;
        const con = document.querySelector('.comment-list');
        
        // let conM = document.defaultView.getComputedStyle(con, null)['marginTop'];
        // conM = parseInt( conM );
        // setTimeout( () => {
        //     const navH = document.querySelector('.detial-module-info > ul').offsetHeight;
        //     const commentH = document.querySelector('.comment-input').offsetHeight;
        //     // con.style.height = devH - commentH - navH -  2 + 'px';
        // },100)
        // 软键盘高度计算
        this.$nextTick( () => {
            this.keyCloseH  = document.body.clientHeight || document.documentElement.clientHeight;    
        })      
        this.loadComment(this.$route.query.uid);
        
    }
}
</script>
<style lang="scss" scoped>
    #comment {
        padding-bottom: 4rem;
        h3 {
            padding-bottom: 1rem;
        }
        &>p {
            text-align: center;
            margin: .5rem 0;
            color: #e99400;
            i {
                font-size: 1.4rem;
            }
        }
        .comment-input {
            
            width: 100%;
            background-color: #fff;
            // height: rem;
            left: 0;
            position: fixed;
            z-index: 10;
            bottom: 0;
            .input-box {
                border: 1px solid #ddd;
                width: 89%;
                border-radius: 4rem;
                overflow: hidden;
                margin: .5rem auto;
                input {
                    height: 3.4rem;
                    outline: none;
                    color: #151515;
                    padding: 0 1rem 0 2rem;
                    width: calc(100% - 4rem);
                }
                button {
                    width: 4rem;
                    height: 3.4rem;
                    background: none;
                    outline: none;
                    i {
                        color: #e99400;
                        font-size: 1.8rem;
                    }
                }
            }
            
        }
        .comment-list {
            border-radius: .5rem;
            // height: 200px;
            background: #fff;
            overflow: scroll;
             ul {
                //  padding: .5rem;
                 li {
                     .user-img-box {
                         overflow: hidden;
                         border-radius: 100%;
                         img {
                             width: 100%;
                         }
                     }
                     .user-info-box {
                        &>p {
                            margin: .5rem 0;
                            color: #e99400;
                        }
                         .user-info {
                            padding:  1rem 0;
                            // height: 2rem;
                            line-height: 2rem;
                            & > span:nth-of-type(1) {
                                // font-family: 'SemiBold_0';
                                color: #151515;
                            }
                            & > span:nth-of-type(3) {
                                font-size: .8rem;
                                // font-family: 'UltraLight_0';
                                color: #a6a6a6;
                            }
                         }
                         .info-box {
                            background-color: #f4f4f4;
                            border-radius: 1rem;
                            border-top-left-radius: 0;
                            padding: 1rem 1.5rem;
                            line-height: 1.6rem;
                            .toole {
                                padding: .5rem 0;
                                color: #757575;
                                .fl {
                                    i {
                                        font: {
                                            size: 1.2rem;
                                        }
                                    };
                                    span {
                                        // font-family: 'Medium_0'
                                        
                                    }
                                }
                                .iconfanyi1 {
                                    margin-left: 2rem;
                                    font-size: 2rem;
                                }
                                .fr {
                                    i { 
                                        color: #ebaa4a;
                                    }
                                    span {
                                        // font-family: 'Medium_0'
                                    }
                                }
                                .isLike{
                                    color: #ebaa4a
                                }
                            }
                            a {
                                text-decoration:underline;
                                color: #757575;
                            }
                         }
                         & > span {
                             color: #666;
                             font-size: .8rem;
                         }
                         p {    
                            word-wrap: break-word;
                             font: {
                                 size: 1rem;
                                //  family: 'UltraLight_0'
                             }
                            //  color: #757575;
                         }
                     }

                     .user-zan-box {
                         text-align: center;
                         width: 3rem;
                         padding: .5rem 0;
                         color: #666;
                         i {
                             display: block;
                             font-size: 1rem;
                         }
                        
                         span {
                             
                             font: {
                                 size: .8rem;
                             }
                         }
                     }
                    //  .reply-list {
                    //      p {
                    //          text-align: center;
                    //           margin: .5rem 0;
                    //      }
                    //  }
                     .comment-con {
                        & > .user-img-box {
                            width: 3rem;
                            height: 3rem;
                        }
                        & > .user-info-box {
                            // width: calc(100% - 5rem)
                            width: 100%;
                        }
                     }
                     & > p {
                        text-align: center;
                        color: #666;
                    }
                     ol {
                         width: 90%;
                         margin-left: 10%;
                         li {
                            .user-img-box {
                                width: 2rem;
                                height: 2rem;
                            }  
                            .user-info-box {
                                // width: calc(100% - 5rem)
                                width: 100%;
                            }
                         }
                     }
                 }
             }
             .beforeLoad {
                 li {
                     margin-top: 1rem; 
                 }
                .name {
                    height: 3rem;
                    background-color: #f4f4f4;
                }
                .con {
                    .sub {
                        width: 90%;
                        margin-top: 10px;
                    }
                    .com {
                        height: 10rem;
                        margin-top: 1px;
                        background-color: #f4f4f4;
                    }
                    p {
                        width: 30%;
                        height: 1rem;
                        margin-top: 1px;
                        background-color: #f4f4f4;
                    }
                }
             }
             h4 {
                 text-align: center
             }
        }
    }
</style>
