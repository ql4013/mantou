<template>
    <div id="imgList">
        <mt-swipe :auto="0" :showIndicators='false' :prevent='true'>
            <mt-swipe-item v-for="(item, index) in imgList" :key="index">
                <img :src="item.imgSrc" alt="">
            </mt-swipe-item>
        </mt-swipe>
    </div>
</template>

<script>
    export default {
        name: 'ImageList',
        data () {
            return {
                imgList: [
                    {
                        imgSrc: require('../assets/img/titimg.png')
                    },
                    {
                        imgSrc: require('../assets/img/titimg.png')
                    },
                    {
                        imgSrc: require('../assets/img/titimg.png')
                    }
                ]
            }
        }
    }
</script>

<style lang="scss" scoped>
    #imgList {
        width: 100%;
        height: 20rem;
        img {
            width: 100%;
            height: 100%;
        }
    }
</style>