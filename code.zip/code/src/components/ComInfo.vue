<template>
    <div id='ConDetial'>
        <div class="detial-user-info clearfix">
            <div class="img-box fl">
                <img :src="content.user_avatar || defaultImg" alt="" srcset="">
            </div>
            <div class="detial-user-tit fl">
                <h4>{{content.user_name ||  'anonymous user'}}</h4>
                <!-- <span>subscribe</span> -->
            </div>
            <!-- <div class="detial-sub fr">
                <i class="iconfont iconshoucang"></i>
                <span>{{$t('other.subscribe')}}</span>
            </div> -->
        </div>
        <!-- <ul class="clearfix">
            <li class="fl">
                <i class="iconfont iconzan vm"></i>
                <span class="vm">{{likes}}</span>
                <span class="vm">{{$t('other.likes')}}</span>
            </li>
            <li class="fl">
                <i class="iconfont iconfenxiang vm"></i>
                <span class="vm"></span>
                <span class="vm">{{$t('other.share')}}</span>
            </li>
        </ul> -->
        <p v-if="content.post_content" class="textH" v-html="content.post_content"></p>
        <a v-if="content.post_content" >
            <i class="iconfont icongengduo" @click="loadMoreHandle($event)"></i>
        </a>
        <div class="correlation-box" v-if="false">
            <h3>{{$t('subTitle.correlation')}}</h3>
            <div class="correlation-list-view">
                <div class="correlation-list-box clearfix">
                    <div class="correlation-list-item fl" v-for="(item, index) in videoList" :key="index">
                        <video-cover :item=item></video-cover>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import videoCover from '../components/VideoCover'
    export default {
        name: 'ConDetial',
        props: ['content'],
        data () {
            return {
                defaultImg: require('../assets/img/titimg.png')
            }
        },
        methods: {
            loadMoreHandle(e) {
                console.log(e.target);
                
                if (document.querySelector('#ConDetial p').className) {
                    e.target.style.transform = 'rotate(180deg)';
                    document.querySelector('#ConDetial p').className= ""
                } else {
                    e.target.style.transform = 'rotate(0deg)';
                    document.querySelector('#ConDetial p').className= "textH"
                }
                  
                
            }
        },
        mounted () {
        },
        components: {
            'video-cover': videoCover,
        }
    }
</script>

<style lang="scss" scoped>
    #ConDetial {
        .textH {
            height: 3.5rem;
            display: -webkit-box;
            overflow: hidden;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;

        }
        .detial-user-info {            
            padding-top: 1rem;
            .detial-user-tit {
                padding-left: 1rem;
                h4 {
                    font-size: 1rem;
                    padding-bottom: .3rem;
                }
                span {
                    color: #666;
                    font-size: 1rem;
                }
            }
            .detial-sub {
                padding: 0 1.5rem;
                height: 2.6rem;
                margin: .5rem 0;
                line-height: 2.6rem;
                border-radius: 1.5rem;
                color: #fff;
                background-color: #e99400;
            }
        }
        ul {
            padding: 2rem 1rem 1rem;
            li {
                width: 50%;
                font: {
                    size: .8rem;
                    weight: 400;
                };
                text-align: center;
            }
        }
        p {
            padding: 1rem 0;
            color: #666;
            line-height: 1.2rem;
            font: {
                size: 1rem;
                weight:400;
            }
        }
        a {
            display: block;
            line-height: 2rem;
            font-weight: bolder;
            color: #ebaa4a;
            text-align: center;
            i {
                display: inline-block;
            }
        }
        .correlation-box {
            // background: rgb(245, 245, 245);
            h3 {
                padding: 1rem 0 0;
                font: {
                    size: 1rem;
                    weight: bolder;
                }
            }
            .correlation-list-view {
                width: 100%;
                padding: 1rem;
                overflow-x: scroll;
                &::-webkit-scrollbar {
                    display: none;
                }
                .correlation-list-box {
                    width: 200%;
                    .correlation-list-item { 
                        margin-left: 1rem;
                        width: calc(25% - 1rem);
                        &:nth-of-type(1) {
                            margin: 0;
                        }
                    }
                }
            }
        }
    }
</style>