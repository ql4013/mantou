// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Axios from 'axios'
import VueI18n from 'vue-i18n'
import Bus from './util/Bus'

import VueAnalytics from 'vue-analytics'

import './assets/css/common.css'
import './assets/css/reset.css'
import './assets/css/mediaquery.css'
import './assets/icon/iconfont.css'
import './assets/banner/iconfont.css'
import 'video.js/dist/video-js.css'

import MintUI from 'mint-ui'
import 'mint-ui/lib/style.css'

import gloabl from './util/Gloabl'

Vue.use(VueI18n)
Vue.use(MintUI)


Vue.use(VueAnalytics, {
  id: 'UA-146428435-1',
  router,
  autoTracking: {
    pageviewOnLoad: false
  }
})

Axios.defaults.baseURL = 'https://api.yooul.net' + (sessionStorage.language ?  ('/' + sessionStorage.language) : '') + '/api'
Axios.defaults.timeout = 30000;

Vue.prototype.$axios = Axios

Vue.config.productionTip = false

const i18n = new VueI18n({
  locale: sessionStorage.language || gloabl.default_language,
  messages: {
    // 印尼语
    'id': require('./lang/id'),
    // 英语
    'en': require('./lang/en'),
    // 中文
    'zh-CN': require('./lang/zh-CN'),
    // 日语
    'ja': require('./lang/ja'),
    // 韩语
    'ko': require('./lang/ko'),
    //印度语
    'hi': require('./lang/hi'),
    // 阿拉伯
    'ar': require('./lang/ar')
  }
})


Vue.filter('timeFil', function(num) {
  return num.split(' ')[0]
})

new Vue({
  el: '#app',
  router,
  i18n,
  data: {
    Bus
  },
  components: { App },
  template: '<App/>'
})
console.log('v1.2.0');