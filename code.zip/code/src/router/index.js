import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/views/Login'
import Home from '@/views/Home'
import Trending from '@/views/Trending'
import Sport from '@/views/Sports'
import Entertain from '@/views/Enterta'
import Detial from '@/views/Detial'
import Setting from '@/views/Setting'
import Search from '@/views/Search'
import Message from '@/views/MessageInform'
import SearchList from '@/views/SearchList'
import Active from '@/views/activityPage'
import MessageDetial from '@/views/MessageDetial'
import Register from '@/views/Register'
import MessagePandect from '@/views/Message'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      redirect: 'home'
    },
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    {
      path: '/register',
      name: 'Register',
      component: Register
    },
    {
      path: '/home',
      name: 'Home',
      component: Home,
      meta: {
        keepAlive: true
      }
    },
    {
      path: '/trending',
      name: 'Trending',
      component: Trending,
      meta: {
        keepAlive: true
      }
    },
    {
      path: '/sport',
      name: 'Sport',
      component: Sport,
      meta: {
        keepAlive: true
      }
    },
    {
      path: '/entertain',
      name: 'Entertain',
      component: Entertain,
      meta: {
        keepAlive: true
      }
    },
    {
      path: '/detial',
      name: 'Detial',
      component: Detial
    },
    {
      path: '/setting',
      name: 'Setting',
      component: Setting
    },
    {
      path: '/search',
      name: 'Search',
      component: Search
    },
    {
      path: '/message',
      name: 'Message',
      component: Message
    },
    {
      path: '/searchlist',
      name: 'SearchList',
      component: SearchList
    },
    {
      path: '/messageDetial',
      name: 'MessageDetial',
      component: MessageDetial
    },
    {
      path: '/active',
      name: 'Active',
      component: Active
    },
    {
      path: '/messagePandect',
      name: 'MessagePandect',
      component: MessagePandect
    }


  ],
})


export default router