<template>
    <div id="message">
        <ul>
            <li v-for="(item, index) in messageList" :key="index" class="clearfix pr" @click="lookDetialHandle(item)">
                <i v-if="item.read"></i>
                <div class="img-box fl">
                    <img :src="item.imgSrc || imgSrc" alt="">
                </div>
                <div class="content fl">
                    <p class="th" v-text="item.title"></p>
                    <!-- <span v-if="item.time">{{item.time}}</span> -->
                    <p class="th con">{{item.title}}</p>
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
    export default {
        name: 'Message',
        data () {
            return {
                imgSrc: 'https://qnidwebother.mmantou.cn/userdefalutavatar.jpg',
                messageList: []
                
            }
        },
        methods: {
            lookDetialHandle (item) {
                this.$router.push({
                    name: 'MessageDetial',
                    query: {
                        text: item.text
                    }
                })
            },
            init() {
                this.$axios.get('/notification').then( res => {
                    this.messageList = res.data.data
                }).catch( err => {

                })
            }
        },
        filters: {
            tostr (str) {
                
                return str[0]
            }
        },
        mounted() {
            this.init()
        }

    }
</script>

<style lang="scss" scoped>
    #message {
        ul {
            background: #fff;
            li {
                padding: 1rem;
                border-bottom: 1px solid #eee;
                i {
                    position: absolute;
                    width: 6px;
                    height: 6px;
                    background: red;
                    border-radius: 100%;
                }
                .content {
                    margin-left: 1rem;
                    width: calc(100% - 5rem);
                    p {
                        width: 100%;
                        padding-bottom: .3rem;

                    }
                    span {
                        color: #999;
                        font-size: .8rem;
                    }
                    .con {
                        font-size: .8rem;
                        color: rgb(39, 39, 39);
                    }
                }
            }
        }
    }
</style>