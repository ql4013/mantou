<template>
    <div id="sports">
        <!-- <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom"   ref="loadmore">       -->
        <div class="content-box"
            v-if="contentList" 
            v-infinite-scroll="loadMoreHandle"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10">
            <content-item   v-for="(item, index) in contentList" :key="index"  :item='item'></content-item>
        </div>           
    </div>
</template>
<script>
import ContentItem from '../components/ContentItem'
import { Indicator } from 'mint-ui';
export default {
    name: 'Trending',
    data () {
        return {
            contentList: [],
            more: true,
            loading: false,
            sportData: null,
        }
    },
    methods: {
        loadBottom() {
            
            setTimeout( () => {
                this.allLoaded = true;
                // this.$refs.loadmore.onBottomLoaded();
            }, 1000)
            
        },
        loadTop() {
            setTimeout( () => {
                this.$refs.loadmore.onTopLoaded();
            }, 1000)
        },
       initLoad() {
            Indicator.open(this.$t('other.loading'))
            this.$axios.get('post?categoryId=group').then( res => {
                this.sportData = res.data;       
               this.contentList = res.data.data;
               Indicator.close();
           }).catch( err => {

           })
       },
       loadMoreHandle () {
           
            const dataList =  this.sportData;
            if (dataList && dataList.links.next) {
                const next = dataList.links.next;
                const urlParams = new URLSearchParams(next);
                
                
                const pageNum = urlParams.get('post_page');
                console.log(pageNum);
                const api = "post?categoryId=group&post_page=" + pageNum;
                this.$axios.get(api).then(data => {    
                    this.contentList.push(...data.data.data)
                    this.sportData = data.data;
                    this.loading = false;
                    Indicator.close();
                })
                this.loading = true;
                Indicator.open(this.$t('other.loading'))
            } else {
                // this.loading = true;
            }
            
        }
    },
    mounted () {
        const devH = document.body.scrollHeight;
        const con = document.querySelector('#sports');
        let conM = document.defaultView.getComputedStyle(con, null)['marginTop'];
        conM = parseInt( conM );
        setTimeout( () => {
            const titH = document.querySelector('#title').offsetHeight;
            con.style.height = devH - titH - (2 * conM) - 2 + 'px';
        },400)
        this.initLoad();
    },
    components: {
        'content-item': ContentItem
    }
}
</script>
<style lang="scss" scoped>
    #sports {
        overflow: hidden;
        overflow-y: scroll;
        padding-bottom: 1rem;
        &::-webkit-scrollbar {
            display: none; //Safari and Chrome
        }
        
        .content-box {
            padding: 1rem;
        }
    .loadmore {
                text-align: center;
                p {
                    color: #d37f00;
                }
            }
        
    }
</style>
