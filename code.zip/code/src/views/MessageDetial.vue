<template>
    <div id="message-detial"> 
        <div v-if="message" v-html="message">
        </div>
    </div>
</template>

<script>
    export default {
        name: 'MessageDetial',
        data () {
            return {
                message: this.$route.query.text
            }
        },
        mounted () {
            localStorage.isNotRead = 1;
            this.$root.Bus.$emit('cancelTip');
        }
    }
</script>

<style lang="scss" scoped>
    #message-detial {
        div {
            margin: 1rem;
            padding: 1rem;
            background: #fff;
            text-indent: 2rem;
        }
    }
</style>