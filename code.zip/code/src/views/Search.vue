<template>
    <div id="search">
        <div class="history">
            <h3>
                <i class="iconfont iconordinaryshijian"></i>
                <span>{{$t('other.historySearch')}}</span>
                <i class="iconfont iconshanchu fr" @click="clearList()"></i>
            </h3>
            <h5 v-if="!historyList.length"> {{$t('other.noHistory')}} </h5>
            <ul v-else class="clearfix">
                <li class="fl" v-for="(item , index) in historyList" :key="index" @click="searchResultHandle(item)">{{item}}</li>
            </ul>
        </div>
        <div class="hot" v-if="false">
            <h3>
                <i class="iconfont iconremen"></i>
                <span>{{$t('other.hotSearch')}}</span>
            </h3>
            <ul class="clearfix">
                <li class="fl" v-for="(item , index) in hotList" :key="index" @click="searchResultHandle(item)">{{item}}</li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {
    name: 'Seach',
    data () {
        return {
            historyList: []
        }
    },
    methods: {
        searchResultHandle (antistop) {
            this.$root.Bus.$emit('searchResult', antistop)
            this.$router.push({
                name: 'SearchList',
                query: {
                    keyword: antistop
                }
            });

        },
        clearList() {
            localStorage.serachHis = [];
            this.historyList = [];

        }
    },
    mounted() {
        if (localStorage.serachHis) {
             this.historyList = JSON.parse(localStorage.serachHis);
        }
       
    },
    beforeDestroy () {

    }
}
</script>
<style lang="scss" scoped>
    #search {
        div {
            padding: 1rem 1rem 0;
            h3 {
                padding: 0 0 1rem;
                // font-weight: bolder;
                i {
                    font-weight: 400
                }
                
            }
            h5 {
                text-align: center;
                font-weight: 400;
                color: #666;
            }
            ul {
                li {
                    padding: .3rem .5rem;
                    margin:.5rem 1rem;
                    min-width: 3rem;
                    text-align: center;
                    background: #ccc;
                    border-radius: .5rem;
                }
            }
        }
    }
</style>
