<template>
    <div id="enterta">
        <div class="content-box"
            v-if="contentList.length"
            v-infinite-scroll="loadMoreHandle"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10">
            <content-item   v-for="(item, index) in contentList" :key="index"  :item='item'></content-item>
        </div> 
        <div v-else>
            <ul class="beforeLoad">
                <li v-for="i in 6">
                    <h3></h3>
                    <div class="con"></div>
                    <div class="meta clearfix">
                        <div class="img-box fl"></div>
                        <div class="con-box fr"></div>
                    </div>
                </li>
            </ul>
        </div>    
    </div>
</template>
<script>
import ContentItem from '../components/ContentItem'
import { Indicator } from 'mint-ui'
import { getList, getListTop } from '../service/api'
export default {
    name: 'Enterta',
    data () {
        return {
            contentList: [],
            entertaData: null,
            more: true,
            loading: false
        }
    },
    methods: {
        loadBottom() {
            
            setTimeout( () => {
                this.allLoaded = true;
            }, 1000)
            
        },
        loadTop() {
            setTimeout( () => {
                this.$refs.loadmore.onTopLoaded();
            }, 1000)
        },
       initLoad() {
        //   并发请求第二页置顶数据和列表数据
           Indicator.open(this.$t('other.loading'));
           
            const p = {
                home: 'true',
                categoryId: '1'
            }
            const p2 = {
                type: 'foot'
            }
            this.$axios.all([getList(p), getListTop(p2)]).then(
                this.$axios.spread( (list, top) => {
                    this.entertaData = list.data;
                    this.contentList = top.data.data;
                    this.contentList.push(...list.data.data)
                    Indicator.close();
                })
            )
            
       },
       loadMoreHandle () {
            
            const dataList =  this.entertaData;
            if (dataList && dataList.links.next) {
                Indicator.open(this.$t('other.loading'))
                const next = dataList.links.next;
                this.loading = true
                
                const urlParams = new URLSearchParams(next);
                const pageNum = urlParams.get('post_page');
                const api = "post?home=true&categoryId=1&post_page=" + pageNum;
                this.$axios.get(api).then(data => {
                    Indicator.close();
                    this.contentList.push(...data.data.data)
                    this.entertaData = data.data;
                    this.loading = false;
                })
            } else {
                this.more = false
            }
            
        }
    },
    mounted () {
        const devH = document.body.scrollHeight;
        const con = document.querySelector('#enterta');
        let conM = document.defaultView.getComputedStyle(con, null)['marginTop'];
        conM = parseInt( conM );
        setTimeout( () => {
            const titH = document.querySelector('#title').offsetHeight;
            con.style.height = devH - titH - (2 * conM) - 2 + 'px';
        },400)
        this.initLoad();
    },
    components: {
        'content-item': ContentItem
    }
}
</script>
<style lang="scss" scoped>
    #enterta {
        overflow: hidden;
        overflow-y: scroll;
        padding-bottom: 1rem;
        &::-webkit-scrollbar {
            display: none; //Safari and Chrome
        }
        
        .content-box {
            padding: 1rem;
        }
        .loadmore {
                text-align: center;
                p {
                    color: #d37f00;
                }
            }
        .beforeLoad {
            padding: 0 1rem;
            li {               
                overflow: hidden;
                margin-top: 1rem;
                border-radius: 1rem;
            }
            h3 {
                height: 3rem;
                background-color: #cccccc85;
            }
            .con {
                height: 5rem;
                margin-top: 1px;
                background-color: #cccccc85;
            }
            .meta {
                margin-top: 1px;
                .img-box {
                    width: 3rem;
                    height: 3rem;

                    border-radius: 100%;
                    overflow: hidden;
                    background-color: #cccccc85;
                }
                .con-box {
                    height: 3rem;
                    width: calc(100% - 4rem);
                    background-color: #cccccc85;
                }
            }
        }
    }
</style>
