<template>
    <div id="login" class="pr">
        <div class="title">
            <i class="iconfont icongengduocopy" @click="backHandle()"></i>
            <span>{{$t('loginOrRegister.register')}}</span>
        </div>
        <ul>
            <li class="clearfix" v-for="(item, index) in loginMeta" :key="index">
                <i class="iconfont vm fl" :class="item.iconClass"></i>
                <input class="vm fl" :type="item.type" v-model="item.val" :placeholder="item.placeholder">
                <i v-if="(item.name == 'pwd' || item.name == 'repeatPwd') &&  !item.isShow" class="iconfont iconyincang fr" @click="showpwd(item)"></i>
                <i v-if="(item.name == 'pwd' || item.name == 'repeatPwd') &&  item.isShow" class="iconfont icondisplay fr" @click="showpwd(item)"></i>
            </li>
        </ul>
        <mt-button type="primary" class="btn" @click="registerHandle()">{{$t('loginOrRegister.register')}}</mt-button>
        <p>
            <span>{{$t('loginOrRegister.haveId')}} </span>
            <a @click="cancleHandle()">{{$t('loginOrRegister.nowLogin')}}</a>
        </p>
    </div>
</template>

<script>
import { Toast } from 'mint-ui';
    export default {
        data () {
            return {
                loginMeta: [
                    {
                        name: 'userName',
                        iconClass: 'iconyonghu-copy',
                        placeholder: this.$t('loginOrRegister.userName'),
                        type: 'text',
                        val: ''
                    },
                    {
                        name: 'pwd',
                        iconClass: 'iconpassword',
                        placeholder: this.$t('loginOrRegister.pwd'),
                        type: 'password',
                        isShow: false,
                        val: ''
                    },
                    {
                        name: 'repeatPwd',
                        iconClass: 'iconpassword',
                        placeholder: this.$t('loginOrRegister.repeatPwd'),
                        type: 'password',
                        isShow: false,
                        val: ''
                    },
                    {
                        name: 'email',
                        iconClass: 'iconyouxiang',
                        placeholder: this.$t('loginOrRegister.email'),
                        type: 'email',
                        val: ''
                    }
                ],
            }
        },
        methods: {
            backHandle() {
                this.$router.push({
                    name: 'Home'
                })
            },
            showpwd (item) {
                item.type === 'text' ? item.type='password' : item.type='text';
                item.isShow = !item.isShow
            },
            //注册句柄
           registerHandle () {
               if (!this.loginMeta[0].val || !this.loginMeta[1].val || !this.loginMeta[2].val || !this.loginMeta[3].val) {
                    Toast(this.$t('other.allNull'));
                    return;
                } else if(this.loginMeta[1].val !== this.loginMeta[2].val) {
                    Toast(this.$t('other.verPwd'));
                } else {
                    this.$axios.post('user/signUp', {
                        name: this.loginMeta[0].val,
                        email: this.loginMeta[3].val,
                        password: this.loginMeta[2].val,
                    }).then( res => {
                       const token = res.data.token_type + ' ' + res.data.access_token;
                       localStorage.token = token;
                       if (res.status === 200) {
                           this.$router.push({
                               name: 'Home'
                           })
                       }

                    }).catch(                      
                        err => { 
                            let errlist = [];
                            switch (err.response.status) {
                                case 422:
                                    if (err.response.data.errors) {
                                        for (const key in err.response.data.errors) {
                                            errlist.push(err.response.data.errors[key][0]);
                                        }
                                    }
                                    Toast(errlist[0]);
                                    
                                    break;
                                case 401:
                                    Toast(err.response.data.message);
                                    break;
                                case 429:
                                    Toast(err.response.data.message);
                                    break;
                            }                       
                        }
                    )
                }
           },
        //    立即登录
           cancleHandle() {
               this.$router.push({
                   name: 'Login'
               })
           }
        },
        mounted () {
            document.querySelector('#login').style.height = document.body.scrollHeight + 'px';
        }
    }
</script>

<style lang="scss" scoped>
    #login {
        .title {
            background-color: #181315;
            height: 4rem;
            line-height: 4rem;
            padding: 0 2rem;
            text-align: center;
            i {
                color: #fff;
                opacity: .8;
                float: left;
                transform:rotate(180deg);
                font-weight: bolder;
                font-size: 1.2rem;
            }
            span {
                font-size: 1.4rem;
                color: #fff;
            }

        }
        ul {
            padding: 5rem 3rem;
            li {
                border-bottom: 1px solid #181214;
                // border: 1px solid red;
                height: 3rem;
                line-height: 3rem;
                margin-top: 1rem;
                i {
                    font-size: 1.5rem;
                    text-align: left;
                }
                
                input {
                    background: none;
                    outline: none;
                    padding: 0 1rem;
                    font: {
                        size: 1.2rem;
                    };
                    height: 100%;
                    width: calc(100% - 3rem)
                }
            }
            
        }
        .btn {
            width: calc(100% - 6rem);
            height: 3.6rem;
            background-color: #181214;
            border-radius: 3.6rem;
            margin-left: 3rem;
        }
        p {
            margin-top: 3rem;
            text-align: center;
            a {
                color: #d28007;
            }
        }
        
    }
</style>