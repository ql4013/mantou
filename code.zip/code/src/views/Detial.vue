<template>
    <div id="detial">
        <div v-if="resourceDetial" class="detial-con pr" :class="{titH:resourceDetial.post_type !='video'}">
            <div class="detial-tit pa" >
                <i class="iconfont icon_zhuye fl" @click='backHandle()'></i>
                <div class="detial-view fr">
                    <i class="iconfont iconchakan vm"></i>&nbsp;
                    <span v-if="resourceDetial.post_view_num" class="vm">{{resourceDetial.post_view_num | nFormatter(1)}}</span>
                    <span v-else class="vm">0</span>
                </div>
            </div>
            <div class="detial-video" v-if="resourceDetial.post_type==='video'">
                <video-player :content='resourceDetial'></video-player>
            </div>
            <div class="detial-imglist" v-if="resourceDetial.post_type==='img'">
                <img-list></img-list>
            </div>
            <div class="detial-media" v-if="resourceDetial.post_type==='text' || resourceDetial.post_type==='news'">
                <media :content='resourceDetial'></media>
            </div>
        </div>
        <div class="detial-info-box">
            
            <div class="detial-info clearfix">
                <div class="fl">
                    <h3>{{resourceDetial.post_title}}</h3>
                    <span>{{resourceDetial.post_created_at | timeFil}}</span>
                </div>
                <!-- <i class="iconfont icontag fr"></i> -->
            </div>
            
        </div>
        
        <!-- 详情模块 -->
        <div class="detial-module-info">
            <ul class="clearfix">
                <li class="fl" @click="commeatHandle()" :class="{selected: active === 'comments'}">{{commentNum + ' ' + $t('subTitle.comments')}}</li>
                <li class="fl"  @click="descHandle()" :class="{selected: active === 'desc'}">{{$t('subTitle.description')}}</li>
            </ul>
            <div class="com" v-if="active==='comments'">
                <com-list></com-list>
            </div>
            <div class="com" v-if="active==='desc'">
                <com-info :content='resourceDetial'></com-info>
            </div>
        </div>
    </div>
</template>
<script>
import VideoPlayer from '../components/Video'
import ImgList from '../components/ImageList'
import Media from '../components/Media'
import ComInfo from '../components/ComInfo'
import ComList from '../components/ComList'
import { Indicator } from 'mint-ui'
import { getDetial } from '../service/api'
export default {
    name: 'Detial',
    data () {
        return {
            active: 'comments',
            type: 'media',
            resource: null,
            isComment: false,
            commentInfo: null,
            origin: window.location.origin,
            commentNum: 0,
            resourceDetial: {
                post_like_num: 0,
                post_type: 'text',
                post_title: '',
                post_created_at: '',
            }
        }
    },
    
    filters: {
        nFormatter(num, digits) {
            const si = [
                { value: 1, symbol: "" },
                { value: 1E3, symbol: "K" },
                { value: 1E6, symbol: "M" },
                { value: 1E9, symbol: "G" },
                { value: 1E12, symbol: "T" },
                { value: 1E15, symbol: "P" },
                { value: 1E18, symbol: "E" }
            ];
            const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
            let i;
            for (i = si.length - 1; i > 0; i--) {
                if (num >= si[i].value) {
                    break;
                }
            }
            return (num / si[i].value).toFixed(digits).replace(rx, "$1") + si[i].symbol;
        }
    },
    methods: {
        backHandle() {
            window.location.href = this.origin + '/#/home';
        },
        commeatHandle () {
            this.active = 'comments'
        },
        descHandle () {
            this.active = 'desc'
        },
        loadDetialInfo() {
            // Indicator.open(this.$t('other.loading'));
            const p = {
                uid: this.$route.query.uid
            }
            getDetial(p).then( res => {
            // this.$axios.get('post/' + this.$route.query.uid).then( res => {
                
                this.resourceDetial = res.data.data;
                
                this.commentNum = res.data.data.post_comment_num || 0;
                // Indicator.close();
                // const commentTop = document.querySelector('.detial-module-info').offsetTop;          
                // this.isComment = this.$route.query.isComment;
                // if (this.isComment) {
                //     document.body.scrollTop = commentTop;
                //     document.documentElement.scrollTop = commentTop;
                    
                // }
            })
        }

    },
    mounted() {
        document.body.scrollTop = 0;
        this.loadDetialInfo();
    },
    beforeDestroy() {
        Indicator.close();
    },
    components: {
        'video-player': VideoPlayer,
        'com-info': ComInfo,
        'com-list': ComList,
        'img-list': ImgList,
        'media': Media
    }

}
</script>
<style lang="scss" scoped>
    #detial {
        .detial-video {
            
        }
        .titH {
            .detial-tit {
                .icon_zhuye {
                    color: #fff;
                    font-size: 1rem;
                    font-weight: 900;
                }
            }
            
        }
        .detial-tit {
            z-index: 5;
            width: 100%;
            top: .8rem;
            height: 2rem;
            line-height: 2rem;
            padding: 0 2rem;
            color: #fff;
            .fl {
                color: #fff;
                background-color: rgba(0, 0, 0, .6);
                display: inline-block;
                width: 2rem;
                height: 2rem;
                text-align: center;
                line-height: 2rem;
                border-radius: 100%;
            }
            .detial-view {
                background: rgba(0, 0, 0, .6);
                padding: 0rem 1.2rem;
                border-radius: 2rem;
                font: {
                    size: 1rem;
                }
                i {
                    font-size: .5rem;
                }
            }
        }
        .detial-info-box {
            // width: 89%;
            padding: 0 5.5%;
            background: #fff;   
            border-bottom: 1px solid #ddd;       
            .detial-info {
                // background-color: #fff;
                padding: 1rem 0;
                .fl {
                    width: 80%;
                    h3 {
                        // font-family: 'SemiBold_0';
                        padding-bottom: .5rem;
                        font: {
                            size: 1.3rem;
                            weight: 600
                        }
                    }
                    span {
                        font-size: .8rem;
                        // font-family: 'UltraLight_0';
                        color: #a6a6a6;
                    }
                }
                .fr {
                    color:  #ebaa4a;
                    line-height: 2rem;
                    margin-right: 1rem;
                    font: {
                        size: 1.4rem;
                        weight: 700;
                    }
                }
            }
            
        }
        
        .detial-module-info {
            background-color: #fff;
            ul {
                border-bottom: 1px solid #ddd;
                li {
                    width: 50%;
                    padding: 1rem 0;
                    color: #a6a6a6;
                    text-align: center;
                    font: {
                        // family: 'Medium_0'
                    }
                }
            };
            .com {
                padding: 0 5.5% 1rem;
            }
            .selected {
                border-bottom: 4px solid #ebaa4a;
                color: #151515;
                font: {
                        // family: 'Boldotf'
                    }
            }
        }
    }
</style>
