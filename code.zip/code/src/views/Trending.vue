<template>
    <div id="trending">
        <div class="home-con">
            <!-- <h1>{{$t('subTitle.mostPopular')}}</h1> -->
            <ul v-if="conList"
                v-infinite-scroll="loadMoreHandle"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="10" >
                <li v-for="(item, index) in conList" :key="index">
                    <!-- <user-info></user-info> -->
                    <div class="con-body" @click='openDetialHandle(item)'>
                        <p class="textType" v-if="item.post_title && !item.post_media">{{item.post_title}}</p>
                        <p class="mediaType" v-if="item.post_title && item.post_media">{{item.post_title}}</p>
                        <div v-if='item.post_media'  class="img-list clearfix pr">
                            <i class="iconfont iconbofang pa" v-if="item.post_media.video && item.post_media.video.video_thumbnail_url"></i>
                            <img class="fl" v-if="item.post_media.news" :src="item.post_media.news.news_cover_image" alt="">
                        </div>
                    </div>
                    
                    <div class="comment-box" @click="detialCommentHandle(item)">
                        <comment v-if='item.topTwoComments' :comList='item.topTwoComments' :comNum='item.post_comment_num' :userImg="item.post_thumbnail_domain + '/' + item.user_avatar"></comment>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
import userInfo from '../components/UserInfo'
import videoCon from '../components/Video'
import comment from '../components/Comment'
import { Toast } from 'mint-ui'
import { Indicator } from 'mint-ui';
export default {
    name: 'Trending',
    data () {
        return {
            scrollTop: 0,
            homeData: {},
            loading: false,
            conList: null,
            more: true,
        }
    },
    methods: {
        openDetialHandle(item) {
            this.$router.push({
                path: '/detial',
                query: {
                    uid: item.post_uuid
                }
            });
        },
        detialCommentHandle (item) {
            this.$router.push({
                path: '/detial',
                query: {
                    isComment: true,
                    uid: item.post_uuid
                }
            })
        },
        loadMoreHandle () {
            const dataList = this.homeData;
            this.loading = true
            if (dataList && dataList.data.links.next) {
                const next = dataList.data.links.next;
                Indicator.open(this.$t('other.loading'))
                const api = "post?categoryId=3&post_page=" + next.split('&')[1].split("=")[1];
                this.$axios.get(api).then(data => {
                    
                    Indicator.close();
                    this.conList.push(...data.data.data)
                    this.homeData = data;
                    this.loading = false
                })
            } else {
                this.more = false
                // Toast(this.$t('other.end'));
            }
            
        },
        init() {
            Indicator.open(this.$t('other.loading'));
            this.$axios.get('post?categoryId=3').then( res => {

                this.conList = res.data.data;
                this.homeData = res;
                
                Indicator.close();
            }).catch( err => {

            })
        }
    },
    //在页面离开时记录滚动位置
    beforeRouteLeave (to, from, next) {
        this.scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        next();
    },
    //进入该页面时，用之前保存的滚动位置赋值
    beforeRouteEnter (to, from, next) {
        next(vm => {
            document.body.scrollTop = vm.scrollTop;
        })
    },
    mounted () {
        this.$nextTick( () => {
            const devH = document.body.scrollHeight;
            
            const con = document.querySelector('.home-con');
            let conM = document.defaultView.getComputedStyle(con, null)['marginTop'];
            
            conM = parseInt( conM );
            setTimeout( () => {
                const titH = document.querySelector('#title').offsetHeight;
                con.style.height = devH - titH - (2 * conM) - 2 + 'px';
            },100)
        })
        
        this.init();
    },
    beforeDestroy() {
        Indicator.close();
    },
    components: {
        'user-info': userInfo,
        'video-con': videoCon,
        'comment': comment
    },

}
</script>
<style lang="scss" scoped>
    #trending {
        
        background: rgb(245, 245, 245);
        padding-bottom: .1rem;
        .home-con {
            width: 89%;
            overflow: scroll;
            margin:  1rem auto;
            h1 {
                padding: 2rem 0;
                font-size: 1.4rem;
                font-weight: 500
            }
            ul {
                
                li {
                    background: #fff;
                    border-radius: .5rem;
                    overflow: hidden;
                    margin-bottom: 1rem;
                    p {
                        margin: 1rem;
                        font-size: 1rem;
                        font-family: 'SemiBold_0';
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;//盒子溢出隐藏
                    }
                    .textType {
                        font-size: 1.2rem;
                    }
                    .img-list {
                        img {
                            width: 100%;
                            margin-left: .5%;
                            &:first-of-type {
                                margin: 0;
                            }
                        };
                        i {
                            z-index: 5;
                            font-size: 4rem;
                            // color: #000;
                            background: #fff;
                            width: 3rem;
                            height: 3rem;
                            line-height: 3rem;
                            text-indent: -10px;
                            border-radius: 100%;
                            left: calc(50% - 2rem);
                            top: calc(50% - 2rem);
                        }
                    }
                }
            }
            .loadmore {
                text-align: center;
                p {
                    color: #d37f00;
                }
            }
        }         
        
    } 
</style>

