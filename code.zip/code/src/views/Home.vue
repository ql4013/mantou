<template>
    <div id="home">
        <div class="home-con">
            <!-- <h1>{{$t('subTitle.mostPopular')}}</h1> -->
            <ul class="con-list" v-if="conList" 
                v-infinite-scroll="loadMoreHandle"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="10">

                <li class='active'>
                    <h3 style="padding-bottom: .5rem" v-text='$t("other.firstLoginTit")'></h3>
                    <div v-html="$t('other.notice')"></div>
                </li>
                <li v-for="(item, index) in conList" :key="index">
                    <!-- <user-info></user-info> -->
                    <div class="con-body" @click='openDetialHandle(item)'>
                        <p class="textType" v-if="item.post_title && !item.post_media"> {{item.post_title}}</p>
                        <p class="mediaType" v-if="item.post_title && item.post_media">{{item.post_title}}</p>
                        <div v-if='item.post_media'  class="img-list clearfix pr">
                            <i class="iconfont iconbofang pa" v-show="item.icon"></i>
                            <img @load="imgload(item)" class="fl" v-if="item.post_media.video" :src="item.post_media.video.video_thumbnail_url" alt="">
                            <img  class="fl" v-if="item.post_media.news" :src="item.post_media.news.news_cover_image" alt="">
                        </div>
                    </div>
                    
                    <div class="comment-box" @click="detialCommentHandle(item)">
                        <comment :comList='item.topTwoComments' :comNum='item.post_comment_num'></comment>
                    </div>
                </li>
            </ul>
            <!-- 预加载样式 -->
            <ul v-else class="beforeLoad">
                <li v-for="i in 3">
                    <h3></h3>
                    <div class="img"></div>
                    <div class="comment clearfix">
                        <div class="img-box fl"></div>
                        <div class="con fr"></div>
                    </div>
                    <div class="comment clearfix">
                        <div class="img-box fl"></div>
                        <div class="con fr"></div>
                    </div>
                    <div class="more"></div>
                </li>
            </ul>
        </div>
        
    </div>
</template>
<script>
import userInfo from '../components/UserInfo'
import videoCon from '../components/Video'
import { getList, getListTop } from '../service/api'
import comment from '../components/Comment'
import { Toast, Indicator, Popup } from 'mint-ui'
import gloabl_lan from '../util/Gloabl'


export default {
    name: 'Home',
    data () {
        return {
            scrollTop: 0,
            homeData: {},
            loading: false,
            conList: null,
            more: true,
        }
    },
    methods: {
        activePage() {
            this.$router.push({
                name: 'Active'
            })
        },
        imgload (item) {
            this.$set(item,'icon',true)
        },
        openDetialHandle(item) {
            this.$router.push({
                path: '/detial',
                query: {
                    uid: item.post_uuid
                }
            });
        },
        detialCommentHandle (item) {
            this.$router.push({
                path: '/detial',
                query: {
                    isComment: true,
                    uid: item.post_uuid
                }
            })
        },
        loadMoreHandle () {
            const dataList =  this.homeData;
            if (dataList && dataList.links.next) {
                this.loading = true;
                Indicator.open(this.$t('other.loading'))
                const next = dataList.links.next.split('?')[1];
                this.loading = true
                const urlParams = new URLSearchParams(next);
                const pageNum = urlParams.get('post_page');
                const params = {
                    home:'true',
                    categoryId:'group',
                    post_page: pageNum
                }
                
                getList(params).then(data => {
                    this.conList.push(...data.data.data)
                    this.homeData = data.data;
                    this.loading = false;
                    Indicator.close();
                })
            } else {
                this.more = false
                Indicator.close();
                // this.loading = true;
            }
            
        },
        init() {
            Indicator.open(this.$t('other.loading'));
            const params = {
                home: 'true',
                categoryId: 'group'
            }
            // 并发请求置顶和首页资源
            this.$axios.all([getListTop(), getList(params)]).then(
                this.$axios.spread( (top, homeList) => {
                    top.data.data.forEach(element => {
                        element.post_title = '🔝  ' + element.post_title
                    });
                    this.conList = top.data.data;
                    this.conList.push(...homeList.data.data);
                    this.homeData = homeList.data;
                    if (!localStorage.firstLogin) {                
                        this.$root.Bus.$emit('showPop', this.$t('other.firstLogin'));
                        localStorage.firstLogin = true;
                    }
                    Indicator.close();
                })
            ).catch(
                err => {
                    Indicator.close();
                    

                    
                }
            )
            // getHomeList(params).then(res => {
            //     Indicator.close();
            
            // })
        }
    },
    //在页面离开时记录滚动位置
    beforeRouteLeave (to, from, next) {
        this.scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        next();
    },
    //进入该页面时，用之前保存的滚动位置赋值
    beforeRouteEnter (to, from, next) {
        next(vm => {
            document.body.scrollTop = vm.scrollTop;
        })
    },
    mounted () {
        const devH = document.body.scrollHeight;
        const con = document.querySelector('.home-con');
        let conM = document.defaultView.getComputedStyle(con, null)['marginTop'];
        conM = parseInt( conM );
        setTimeout( () => {
            const titH = document.querySelector('#title').offsetHeight;
            con.style.height = devH - titH - (2 * conM) - 2 + 'px';
        },100)
        this.init();
    },
    beforeDestroy() {
        Indicator.close();
    },
    components: {
        'user-info': userInfo,
        'video-con': videoCon,
        'comment': comment
    },

}
</script>
<style lang="scss" scoped>
    #home {
        padding-bottom: .1rem;
        .home-con {
            width: 89%;
            overflow: scroll;
            margin:  1rem auto;
            h1 {
                padding: 2rem 0;
                font-size: 1.4rem;
                font-weight: 500
            }
            .con-list {
                .active {
                    border: 1rem solid #fff;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 6;
                    overflow: hidden;//盒子溢出隐藏
                    h3 {
                        // font-family: 'SemiBold_0';
                        
                    }
                }
                li {
                    background: #fff;
                    border-radius: .5rem;
                    overflow: hidden;
                    margin-bottom: 1rem;
                    p {
                        margin: 1rem 1rem 0rem;
                        font-size: 1rem;
                        // font-family: 'SemiBold_0';
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;//盒子溢出隐藏
                    }
                    .textType {
                        font-size: 1.2rem;
                    }
                    .img-list {
                        padding: .5rem 0rem;
                        img {
                            width: 100%;
                            margin-left: .5%;
                            &:first-of-type {
                                margin: 0;
                            }
                        };
                        i {
                            z-index: 5;
                            font-size: 4rem;
                            // color: #000;
                            background: #fff;
                            width: 3rem;
                            height: 3rem;
                            line-height: 3rem;
                            text-indent: -10px;
                            border-radius: 100%;
                            left: calc(50% - 2rem);
                            top: calc(50% - 2rem);
                        }
                    }
                }
            }
            .loadmore {
                text-align: center;
                p {
                    color: #d37f00;
                }
            }
        }  
        .beforeLoad {       
            li {
                margin-top: 1rem;
                border-radius: 1rem;
                overflow: hidden;
            }
            h3 {
                height: 3rem;
                background-color: #cccccc85;
            }
            .img {
                height: 10rem;
                margin-top: 1px;
                background-color: #cccccc85;
            }
            .comment {
                height: 3rem;
                margin-top: 1px;
                // background-color: rgb(223, 218, 218);
                .img-box {
                    width: 3rem;
                    height: 3rem;
                    background-color: #cccccc85;
                    border-radius: 100%;
                    overflow: hidden;
                }
                .con {
                    height: 3rem;
                    width: calc(100% - 4rem);
                    background-color:#cccccc85;
                }
            }
            .more {
                height: 3rem;
                margin-top: 1px;
                background-color: #cccccc85;
            }
        }       
    } 
</style>

