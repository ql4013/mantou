<template>
    <div id="active" >
        <h3>{{eventTitle}}</h3>
        <p v-html="eventContent"></p>
        <div v-for="(item, index) in videoList" :key="index">
            <video v-if="item" :src="item" controls :style="sty"></video>
        </div>
        
    </div>
    
</template>

<script>
    export default {
        name: 'Active',
        data () {
            return {
                "eventTitle":"",
                "eventContent":"",
                "videoList":[],
                "eventImg":"http://www.baidu.com",
                "eventStartTime":"2018-05-07 16:00:00",
                "eventEndTime":"2020-11-20 23:59:59",
                "eventStatus":"1",
                sty: {
                    width: '0px'
                }

            }
        },
        mounted() {
            const scrW = document.querySelector('#active').offsetWidth;
            this.sty.width = scrW + 'px';
            this.$axios.get('event').then(
                res => {
                    const {eventContent, eventTitle, eventVideo} = res.data
                    this.eventTitle = eventTitle;
                    this.eventContent = eventContent;

                    this.videoList = eventVideo.split(';');
                }
            )
        },
    }
</script>

<style lang="scss" scoped>
#active {
    width: calc(100% - 2rem);
    margin: auto;
    padding: 1rem 0;
    overflow: hidden;
    h3 {
        padding: 1rem 0;
    }
    p {
        line-height: 1.8rem;
        padding-bottom: 2rem;
    }
}
</style>