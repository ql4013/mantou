<template>
    <div id="message">
        <ul class="nav clearfix">
            <li class="fl active">{{$t('other.message')}}</li>
            <li class="fl">{{$t('other.reply')}}</li>
            <li class="fl">{{$t('other.likes')}}</li>
        </ul>
        <!-- 回复or喜欢 -->
        <div class="rep-or-like">
            <ul>
                <li v-for="(item, index) in likesList" :key="index">
                    <div class="clearfix">
                        <div class="img-box fl vm">
                            <img :src="item.user_avater" alt="">
                        </div>
                        <span class="fl name">{{item.user_name}}</span>
                        <span class="fl time">{{item.time}}</span>
                        <span class="fr reply">Reply</span>
                    </div>
                    <div class="con">
                        <p class="main">
                            <span>{{item.author}}</span> {{item.con}}
                        </p>
                        <p v-if="item.type == 'like'" class="tit">{{$t('other.likes')}}</p>
                        <p v-if="item.type == 'reply'" class="tit">{{$t('other.reply')}}</p>
                        <!-- 赞or回复 -->
                        <div class="tool clearfix" v-if="item.type == 'reply'">
                            <div class="fl">
                                <i class="iconfont"></i>
                                <span>{{item.zanNum}}</span>
                            </div>
                            <div class="fr">{{$t('other.reply')}}</div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <!-- 系统消息界面 -->
        <div class="system">
            <ul>
                <li v-for="(item, index) in systemList" :key="index">
                    <div class="clearfix">
                        <span class="fl name">{{item.user_name}}</span>
                        <span class="fl time">{{item.time}}</span>
                        <span class="fr del">Delete</span>
                    </div>
                    <p class="con">{{item.con}}</p>
                    <a>view the details</a>
                </li>
            </ul>        
        </div>
        <!-- 评论详情 -->
        <div class="comment">
            
        </div>
        <!-- 预加载样式 -->
        <div class="before-com">
            
        </div>
    </div>
</template>

<script>
    import { TabContainer, TabContainerItem } from 'mint-ui'
    export default {
        name: 'Message',
        data () {
            return {
                likesList: [
                    {
                        type: 'like',
                        user_avater: require('../assets/img/titimg.png'),
                        user_name: 'person',
                        time: '2019-01-11',
                        author: 'Author',
                        con: 'Americans live in their own world, even their next door neighbor, Canada, they can’t name the capital city or the Prime Minister in power today.'
                    },
                    {
                        type: 'reply',
                        user_avater: require('../assets/img/titimg.png'),
                        user_name: 'person',
                        time: '2019-01-11',
                        author: 'Author',
                        con: 'Americans live in their own world, even their next door neighbor, Canada, they can’t name the capital city or the Prime Minister in power today.'
                    }
                ],
                systemList: [
                    {
                        user_avater: 123,
                        user_name: 123,
                        time: 123,
                        author: '123',
                        con: '123'
                    }
                ]
            }
        }

    }
</script>

<style lang="scss" scoped>
    #message {
        .nav {
            height: 2.4rem;
            line-height: calc(2.4rem - 3px);
            color: #fff;
            font-weight: 500;
            background-color: #141212;
            li {
                width: 33.33%;
                text-align: center;
            }
            .active {
                border-bottom: 3px solid #d37f00;
            }
        }
        .rep-or-like {
            border: 1px solid red;
            padding: 1rem 5.5%;
            ul {
                li {
                    background-color: #fff;
                    padding: .5rem .8rem;
                    border-radius: 1rem;
                    margin-top: 1rem;
                    .clearfix {
                        line-height: 2.6rem;
                        .img-box {
                            margin-right: 1rem;
                        }
                    }
                    .con {
                        margin-left: 3.6rem;
                    }
                }
            }
        }
    }
</style>