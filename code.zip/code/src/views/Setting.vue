<template>
    <div id="set">
        <div class="set-tit pr">
            <div class="set-tit-bg"></div>
            <div class="user-img pa">
                <img :src="imgSrc" alt="">
                <i class="iconfont icontupian"></i>
            </div>
            <div class="upload-img pa" v-if="isSelf">
                <i class="iconfont icontupian pa"></i>
                <input type="file" @change="imgUpload()">
            </div>
            <h4>
                <p class="name">{{userName}}</p>
                <!-- <input v-else class="name" type="text" v-model='userName' @change="nameLoad()"> -->
                <!-- <span v-if="!isSelf" class="nation">Indonesia</span> -->
                <!-- <input v-else type="text" v-model="userNation" class="nation"> -->
            </h4>
        </div>
        <!-- <h3 v-if="isSelf">{{$t('other.myCollection')}}</h3> -->
        <!-- <h3 v-if="!isSelf">{{$t('other.hisPublication')}}</h3> -->
        <!-- <div class="content-box">
            <content-item  v-for="(item, index) in contentList" :key="index" :item='item'></content-item>
        </div> -->
        <div class="tip">{{$t('other.noContent')}}</div>
        <mt-button v-if="isSelf" class="logout" type="danger" @click.native="logouthandleClick">{{$t('loginOrRegister.logout')}}</mt-button>
    </div>
</template>
<script>
import ContentItem from "../components/ContentItem"
import { Indicator } from 'mint-ui'
import { Toast } from 'mint-ui'
import { MessageBox } from 'mint-ui';
import { getUserInfo, getUserContent, getLoginContent, getLoginUserInfo } from '../service/api'
export default {
    name: 'Setting',
    data () {
        return {
            imgSrc: localStorage.imgSrc || 'https://qnidimage.mmantou.cn/userdefalutavatar.jpg',
            userName: '',
            userNation: '',  
            isSelf: false,
            imgToken: "",
            contentList: [],
            qnBaseUrl: 'https://qnidwebother.mmantou.cn'
        }
    },
    methods: {
        loadInfo(uid) {
            // 他人信息接口
            if (uid) {
                this.isSelf = false;
                const getUserInfo = () => {
                    return this.$axios.get('user/' + uid);
                }
                const getContentList = () => {
                    return this.$axios.get('post/user/' + uid);
                }
                Indicator.open(this.$t('other.loading'))
                this.$axios.all([getUserInfo(), getContentList()])
                .then( this.$axios.spread( (userInfo, contentList) => {
                    this.imgSrc = userInfo.data.data.user_avatar;
                    this.userName = userInfo.data.data.user_name;
                    this.userNation = userInfo.data.data.user_language;
                    this.contentList = contentList.data.data;
                    Indicator.close();
                }))
                // 当前用户信息
            } else {
                this.isSelf = true;
                // const getUserInfo = () => {
                //     return this.$axios.get('user/profile');
                // }
                const getContentList = () => {
                    return this.$axios.post('post/userself');
                }
                this.$axios.defaults.headers.common['Authorization'] = localStorage.token;
                this.$axios.all([getContentList()])
                .then( this.$axios.spread( ( contentList) => {  
                    this.contentList = contentList.data.data;
                    // localStorage.token = res.config.headers.Authorization;
                })).catch( err => {
                    const  status  = err.response.status;                 
                   if (status && (status == 401 || status == 500)) {
                        MessageBox({
                            title: this.$t('other.tip'),
                            message: this.$t('other.login'),
                            showCancelButton: true,
                            confirmButtonText: this.$t('other.ok'),
                            cancelButtonText: this.$t('other.cancel')
                        }).then(action => {
                            if (action == 'confirm') {
                                this.$router.push({
                                    name: 'Login'
                                })
                            } else {
                                return;
                            }
                            
                        });
                    } else {
                        
                        Toast(err.response.data.message)
                    }
                    
                })
            }       
        },
        loadContentList(uid) {

        },
        imgUpload() {
            Indicator.open('Mengunggah ...');
            this.$axios.defaults.headers.common['Authorization'] = localStorage.token;
            this.$axios.get('/user/getqntoken').then( res => {
                this.imgToken = res.data.qntoken;
                const f = document.querySelector('.upload-img input');
                const timestamp = Date.parse(new Date());
                let fSuffix = f.files[0].name;
                fSuffix = fSuffix.split('.')[1];
                const formData = new window.FormData();
                formData.append('file', f.files[0])        
                formData.append('token', this.imgToken);
                formData.append('key', 'avatar' + timestamp + '.' + fSuffix);
                const options = {
                    url: 'http://up-z1.qiniu.com',
                    data: formData,
                    method: 'post',
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
                this.$axios.defaults.headers.common['Authorization'] = localStorage.token; 
                this.$axios(options).then( res => {
                    Indicator.close();
                    localStorage.token = res.config.headers.Authorization;

                    this.imgSrc = this.qnBaseUrl + '/' +  res.data.key;
                    
                    localStorage.setItem('imgSrc',  this.imgSrc);

                    this.$root.Bus.$emit('updateUserImg', this.imgSrc)
                    const r = {
                        user_avatar: res.data.key
                    }
                    this.updateuserInfo(r)
                }).catch( err => {             
                    const errCode = err.response.status;
                    Indicator.close();
                    if (errCode && (errCode == 401 || errCode == 500)) {
                        MessageBox({
                            title: this.$t('other.tip'),
                            message: this.$t('other.login'),
                            showCancelButton: true,
                            confirmButtonText: this.$t('other.ok'),
                            cancelButtonText: this.$t('other.cancel')
                        }).then(action => {
                            if (action == 'confirm') {
                                this.$router.push({
                                    name: 'Login'
                                })
                            } else {
                                return;
                            }
                            
                        });
                    } else {
                        
                        Toast(err.response.data.message)
                        this.$router.go(-1);
                    }
                })
            }).catch(
                err => {
                    const { response } = err;
                    Toast(response.data.message)
                }
            )
           
            
        },

        nameLoad () {
            const r = {
                user_name: this.userName
            }
            this.updateuserInfo(r);
        },
        updateuserInfo(r) {
            this.$axios.put('user/updateuserinfo', r).then( res => {
                console.log(res.data);
                Toast(this.$t('other.modifySuccess'))
            }).catch(
                err => {

                }
            )
        },
        logouthandleClick () {
            this.$axios.get('/user/signOut').then(res => {

                localStorage.token='';
                localStorage.userName = '';
                localStorage.imgSrc = 'https://qnidimage.mmantou.cn/userdefalutavatar.jpg'
                this.$router.push({
                    name: 'Home'
                })
                // 通知公共头部头像恢复默认
                this.$root.Bus.$emit('clearUserInfo')
            }).catch( err => {

            })
            
        }

    },
    mounted () {  
        this.loadInfo(this.$route.query.uid);
    },
    beforeDestroy() {
        Indicator.close();
    },
    components: {
        'content-item': ContentItem
    }
}
</script>
<style lang="scss" scoped>
    #set {
        
        .set-tit {
            background-color: #fff;
            .upload-img  {
                width: 8rem;
                left: calc(50% - 4rem);
                top: 0;
                height: 8rem;
                input {
                    display: inline-block;
                    outline: none;
                    width: 8rem;
                    opacity: 0;
                    height: 8rem;
                    border-radius: 100%;
                    border: 1px solid red;
                }
                i {
                    font: {
                        size: 2rem;
                    }
                    color: #fff;
                    width: 8rem;
                    height: 8rem;
                    line-height: 8rem;
                    text-align: center;
                    border-radius: 100%;
                    overflow: hidden;
                    background: rgba(0, 0, 0, 0.3);
                }
            }
            .set-tit-bg {
                height: 4rem;
                background-color: #141212;
            }
            .user-img {
                width: 8rem;
                height: 8rem;
                left: calc(50% - 4rem);
                top: 0;
                border: 4px solid #fff;
                border-radius: 100%;
                overflow: hidden;
                box-shadow: 0px 6px 10px #666;
                img {
                    width: 100%;
                    height: 100%;
                }
                
            }
            h4 {
                font-family: '微软雅黑';
                padding: 5rem 0 .5rem; 
                border-bottom: 1px solid #ddd;
                text-align: center;
                input {
                    display: block;
                    width: 50%;
                    margin: auto;
                    text-align: center;
                    outline: none;
                }
                .nation {
                    font: {
                        size: .8rem;
                        weight: 400;
                    }
                    color: #666;
                }
            }
        }
        h3 {
            padding: 1rem;
            font: {
                family: '微软雅黑'
            }
        }
        .tip {
            padding: 2rem;
            text-align: center;
            color: #666;
        }
        .content-box {
            padding: 0 1rem 1rem;
        }
        .logout {
            width: 80%;
            margin: auto 10%;
            position: fixed;
            bottom: 2rem;
        }
    }
</style>
