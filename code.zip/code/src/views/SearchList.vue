<template>
    <div id="search-list">
        <h2>{{$t('subTitle.searchResult')}}</h2>
        <div v-if="!isnoResulte" 
            v-infinite-scroll="loadMoreHandle"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10">
            <content-item v-for="(item, index) in searchList" :key="index" :item='item'></content-item>
        </div>       
        <div v-else class="noResult">{{$t('other.noResult')}}</div>
    </div>
</template>

<script>
    import ConentItem from '../components/ContentItem'
    import { Toast } from 'mint-ui'
    import { Indicator } from 'mint-ui'
    export default {
        name: 'SearchList',
        data () {
            return {
                searchList: [],
                isnoResulte: false,
                more: true,
                loading: false,
                searchData: null,
            }
        },
        methods: {
            loadData () {
                Indicator.open(this.$t('other.loading'));
                const source = this.$route.query.keyword;
                this.isnoResulte = false;
                if(source){
                    if(localStorage.serachHis) {
                        let  serachHisList = JSON.parse(localStorage.serachHis);
                        if (serachHisList.indexOf(source) == -1) {
                            serachHisList.unshift(source);
                            localStorage.serachHis = JSON.stringify(serachHisList)
                        }
                        
                        // localStorage.serachHis.push(source)
                    } else {
                        localStorage.setItem('serachHis', '')
                        const serachHisList = [];
                        serachHisList.push(source);
                        localStorage.serachHis = JSON.stringify(serachHisList);
                    }

                    this.searchList = [];
                    this.$axios.get('post?keywords=' + source).then( res => {
                        console.log(res.data.data);
                        
                        this.searchList = res.data.data;
                        this.searchData = res;
                        Indicator.close();
                        if (res.data.data.length == 0) {
                            this.isnoResulte = true
                        }
                    }).catch( err => {

                    })
                } 
            },
            loadMoreHandle () {
                const dataList = this.searchData;
                const source = this.$route.query.keyword;
                
                if (dataList && dataList.data.links.next) {
                    const next = dataList.data.links.next
                    Indicator.open(this.$t('other.loading'))
                    this.$axios.get('post?keywords=' + source + "&post_page=" +  next.split('&')[1].split("=")[1]).then( res => {
                        this.searchList.push(...res.data.data);
                        this.searchData = res;     
                        Indicator.close();
                    }).catch( err => {

                    })
                } else {
                    this.more = false
                }
            }
        },
        mounted () {
            const devH = document.body.scrollHeight;
            const titH = document.querySelector('#title').offsetHeight;
            const con = document.querySelector('#search-list');
            const h2H = document.querySelector('#search-list h2').offsetHeight;
            let conM = document.defaultView.getComputedStyle(con, null)['paddingTop'];
            
            conM = parseInt( conM );
            con.style.height = devH - titH - (2 * conM) - 2 + 'px';
            this.loadData();
            this.$root.Bus.$on('searchResult', this.loadData);          
        },
        beforeDestroy() {
            this.$root.Bus.$off('searchResult')
        },
        components: {
            'content-item': ConentItem
        }
    }
</script>

<style lang="scss" scoped>
    #search-list {
        padding: 0 1rem 1rem;
        width: 100%;
        overflow-x: scroll;
        h2 {
            padding: 1rem;
            font-weight: 900
        }
        .noResult {
            text-align: center;
            color: #666;
            padding-top: 3rem;
        }
    }
</style>