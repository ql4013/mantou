<template>
    <div id="login" class="pr">
        <div id="login" class="pr">
            <div class="title">
                <i class="iconfont icongengduocopy" @click="backHandle()"></i>
                <span>{{$t('loginOrRegister.login')}}</span>
            </div>
            <ul>
                <li class="clearfix">
                    <i class="iconfont iconyonghu-copy vm fl"></i>
                    <input class="vm fl username" type="text" v-model="userName" :placeholder="$t('loginOrRegister.userName')">
                </li>
                <li class="clearfix">
                    <i class="iconfont iconpassword vm fl"></i>
                    <input class="vm fl pwd" type="password" v-model="pwd" :placeholder="$t('loginOrRegister.pwd')">
                    <i class="iconfont iconyincang fl" @click="showpwd($event)"></i>
                </li>
            </ul>
            <mt-button type="primary" class="lbtn btn" @click="loginHandle()">{{$t('loginOrRegister.login')}}</mt-button>
            <mt-button type="primary" class="sbtn btn" @click="registerHandle()">{{$t('loginOrRegister.register')}}</mt-button>
            <!-- <p class="clearfix">
                <span class="fl"></span>
                <span class="fl">OR</span>      
                <span class="fl"></span>  
            </p>
            <div class="third">
                <img src="../assets/img/fb.png" alt="">
                <img src="../assets/img/gg.png" alt="">
            </div> -->
        </div>
    </div>
</template>

<script>
    import { Toast } from 'mint-ui';
    export default {
        data () {
            return {
                userName: '',
                pwd: '',
                isshowPwd: false,
            }
        },
        methods: {
            backHandle() {
                this.$router.push({
                    name: 'Home'
                })
            },
            loginHandle() {
                if (!this.userName || !this.pwd) {
                    Toast(this.$t('other.loginNull'));
                    return;
                } else {
                    this.$axios.post('user/signIn', {
                        name: this.userName,
	                    password: this.pwd
                    }).then( res => {
                        if (res.status === 200) {
                            localStorage.userName = res.data.user.user_name;
                            localStorage.imgSrc = res.data.user.user_avatar;
                            this.$root.Bus.$emit('clearUserInfo');
                            localStorage.token = res.data.token_type + ' ' + res.data.access_token;
                            this.$router.go(-1);
                        }
                    }).catch( err => {

                        const errCode = err.response.status;
                        if (err.response) {
                            let errlist = [];
                            switch (errCode) {
                                case 422:
                                    if (err.response.data.errors) {
                                        for (const key in err.response.data.errors) {
                                            errlist.push(err.response.data.errors[key][0]);
                                        }
                                    }
                                    Toast(errlist[0]);
                                    
                                    break;
                                case 401:
                                    Toast(err.response.data.message);
                                    break;
                                case 429:
                                    Toast(err.response.data.message);
                                    break;
                            }    
                        }
                    })
                }
                
            },
            registerHandle () {
                this.$router.push({
                    name: 'Register'
                })
            },
            showpwd(e) {
                if (!this.isshowPwd) {

                    document.querySelector('#login .pwd').setAttribute('type', 'text');
                    e.target.className = 'iconfont icondisplay fl'
                } else {
                    document.querySelector('#login .pwd').setAttribute('type', 'password');
                    e.target.className = 'iconfont iconyincang fl'
                }
                this.isshowPwd = !this.isshowPwd;
            }
        },
        mounted () {
            this.userName = '';
            this.pwd = '';
            document.querySelector('#login').style.height = document.body.scrollHeight + 'px';
        }
    }
</script>

<style lang="scss" scoped>
    #login {
        
        .title {
            background-color: #181315;
            height: 4rem;
            line-height: 4rem;
            padding: 0 2rem;
            text-align: center;
            i {
                color: #fff;
                opacity: .8;
                float: left;
                transform:rotate(180deg);
                font-weight: bolder;
                font-size: 1.2rem;
            }
            span {
                font-size: 1.4rem;
                color: #fff;
            }

        }
        ul {
            padding: 5rem 3rem;
            li {
                border-bottom: 1px solid #181214;
                // border: 1px solid red;
                height: 3rem;
                line-height: 3rem;
                margin-top: 1rem;
                i {
                    font-size: 1.5rem;                        ;
                }
                
                input {
                    background: none;
                    outline: none;
                    padding: 0 1rem;
                    font: {
                        size: 1.2rem;
                    };
                    height: 100%;
                    width: calc(100% - 3rem)
                }
                
            }
            
        }
        .btn {
            width: calc(100% - 6rem);
            height: 3.6rem;           
            border-radius: 3.6rem;
            margin-left: 3rem;
        }
        .lbtn {
            background-color: #181214;
        }
        .sbtn {
            background-color: rgba(0, 0, 0, 0);
            margin-top: 1rem;
            color: #161616;
            border: solid 1px #cccccc;
        }
        p {
            margin: 3rem auto 1rem;
            text-align: center;
            height: 2.4rem;
            width: calc(100% - 6rem);
            
            line-height: 2.4rem;
            span {
                margin-top: 1.2rem;
                width: calc(50% - 1.2rem);
                border: 1px solid #fff;
            }
            span:nth-of-type(2) {
                width: 2.4rem;
                height: 2.4rem;
                font-size: .8rem;
                margin: 0;
                border-radius: 100%;
                background: #fff;
            }
        }
        .third {
            text-align: center;
            img {
                width: 6rem;
                margin: 0 1rem;
            }
        }
    }
</style>