import axios from 'axios'
import QS from 'qs'
import router from '../router'
import Toast from 'mint-ui'

const instance = axios.create({
    timeout: 30000,
    baseURL: 'https://api.yooul.net' + (sessionStorage.language ?  ('/' + sessionStorage.language ) : '') + '/api'
});
instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'
// 请求拦截器
instance.interceptors.request.use(
    config => {
        const token = localStorage.token;
        token && (config.headers.Authorization = token);
        return config
    },
    error =>  Promise.error(error)
);
//响应拦截器
instance.interceptors.response.use(
    // 请求成功
    res => res.status == 200 ? Promise.resolve(res) : Promise.reject(res),
    // 请求失败 
    error => {
        const {response} = error;
        if (response) {
            errorHandle(response.status, response.data.message);
            return Promise.reject(response)
        }
        const {message} = error;
        if (message.indexOf('timeoout') != -1) {
            console.log(message);
            
        }
    }
)
const errorHandle = (status, other) => {
    switch (status) {
        case 401:
            Toast(other)
            break;
        
        default: Toast(other)       
            break;
    }
}
export default instance