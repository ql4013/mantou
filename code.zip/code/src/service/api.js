import http from './http'
// 获取页面数据列表
export const getList        = p => http.get('/post', {params: p});
// 获取置顶数据
export const getListTop      = p => http.get('/post/top', {params: p});
// 获取评论列表
export const getCommentList     = p => http.get('/postComment/post/' + p.uid + '?children=true');
// 获取资源详情
export const getDetial          = p => http.get('/post/' + p.uid);
// 获取非本人用户信息
export const getUserInfo        = p => http.get('/user/' + p.uid);
// 获取非本人内容列表
export const getUserContent     = p => http.get('/post/user/' + 1544);
// 获取登录用户内容列表
export const getLoginContent    = p => http.get('/post/userself');
// 获取登录用户信息
export const getLoginUserInfo   = p => http.get('/user/profile');
// 获取搜索结果列表页
export const getSearchList      = p => http.get('/post/', {params: p});
// 登录
export const login              = p => http.post('/user/signIn/', p);
//注册
export const register           = p => http.post('/user/signUp/', p);
// 登出
export const logout             = p => http.get('/user/signOut/', {params: p});
// 获取七牛云token
export const getqnToken         = p => http.get('/user/getqntoken/', {});
// 修改用户信息
export const updateUserInfo     = p => http.post('/', p);
// 取消赞
export const removeLike         = p => http.put('/postComment/' + p.comment_id + '/revokeVote');
// 点赞
export const like               = p => http.put('/postComment/' + p.comment_id + '/like');
// 提交评论
export const uploadCommetn      = p => http.put('/postComment/', p);



