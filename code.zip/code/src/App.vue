<template>
  <div id="app">
    <tit :isHome='isHome' v-if='hasTit' :isSearch='isSearch' :isOpen='isOpen'></tit>
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view v-if='!$route.meta.keepAlive'></router-view>
    <mt-popup v-model="popupVisible" popup-transition="popup-fade" class="pop pr">
        <div class="popContent">
            <p>{{tipCon}}</p>
        </div>
        <span class="pa" @click="popupVisible = false">×</span>
    </mt-popup>
  </div>
</template>
<script>
    import tit from './components/ComTitle'
    export default {
        name: 'App',
        data () {
            return {
                isHome: false,
                hasTit: true,
                isSearch: false,
                isOpen: false,
                popupVisible: false,
                tipCon: ''
            }
        },
        methods: {
            routerSwitchHandle() {           
                this.isHome = false;
                this.hasTit = true;
                const routeName = this.$route.name;
                const routeTo = this.$route.to;
                const routeFrom = this.$route.from;
                if (routeName === 'Home' || routeName === 'Trending' || routeName === 'Sport' || routeName=== 'Entertain') {
                    this.isHome = true
                }
                if (routeName === 'Login' || routeName === 'Detial' || routeName === 'Register') {
                    this.hasTit = false;
                }
                if (routeName !== 'Search' && routeName !== 'SearchList' && routeName!== 'Detial') {                  
                    this.$root.Bus.$emit('clearSearch');
                }   
            }
        },
        watch:{
            '$route': 'routerSwitchHandle'
        },
        mounted () {       
            // 模拟铃铛标记
            localStorage.isNotRead = localStorage.isNotRead ||  0;

            this.routerSwitchHandle();
            document.querySelector('#app').style.minHeight = document.querySelector('body').offsetHeight + 'px';
            this.$root.Bus.$on('showPop', con => {
                this.popupVisible = true,
                this.tipCon = con
            })
        },
        components: {
            tit
        },
        destroyed() {
            this.$root.Bus.$off('showPop');
        }
    }
</script>
<style lang="scss" scoped>
    #app {
        background-color: #f6f5fa;
        .pop {
            width: 70%;
            border-radius: 1rem;
            padding: 1rem;
            p {
                text-indent: 2em;
                // margin-top: 1rem;
            }
            span {
                top: -1.6rem;
                right: -1.6rem;
                width: 2rem;
                height: 2rem;
                text-align: center;
                line-height: 2rem;
                color: #fff;
                font-size: 2rem;
                
            }
        }
    }
</style>

