let current = navigator.language || navigator.userLanguage;
if (current.indexOf('-') != -1 && current.indexOf('en') != -1) {
    current = current.split('-')[0];
}
const gloabl = {
    // 获取浏览器默认语言

    default_language:  current || 'en'
}
export default gloabl